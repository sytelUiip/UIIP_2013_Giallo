package it.gruppogiallo.dto.test;

import it.gruppogiallo.entity.Account;

import org.apache.log4j.xml.DOMConfigurator;

public class DTOTest {

	public static void main(String[] args) {
		// Test DTO class and log4j
		//DOMConfigurator.configure("log4j.xml");
		Account account= new Account();
		Account accoun2= new Account("testUsername", "testPw", "testNome", "testCognome", "testEmail", "testSiglaGiornalista", "testSiglaRedazione", "testStato");
		//Gruppo gruppo = new Gruppo("Test"); 
		//Funzionalita funzionalita = new Funzionalita("siglaFunzionalita", "nomeFunzionalita", gruppo);
	}

}
