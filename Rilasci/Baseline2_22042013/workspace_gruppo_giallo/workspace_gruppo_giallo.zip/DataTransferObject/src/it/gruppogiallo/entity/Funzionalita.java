package it.gruppogiallo.entity;

/*import org.apache.log4j.Logger;*/

public class Funzionalita extends DTO {

	private static final long serialVersionUID = 1L;
	private String siglaFunzionalita;
	private String nomeFunzionalita;
	private Gruppo gruppo;
	/*private static final Logger logger = Logger.getLogger(Funzionalita.class);*/
	
	public Funzionalita(String siglaFunzionalita,
			String nomeFunzionalita, Gruppo gruppo) {
		this.siglaFunzionalita = siglaFunzionalita;
		this.nomeFunzionalita = nomeFunzionalita;
		this.gruppo = gruppo;
		/*logger.debug("Class: Funzionalita - "+" constructor called in DTO");*/
	}

	public String getSiglaFunzionalita() {
		return siglaFunzionalita;
	}

	public void setSiglaFunzionalita(String siglaFunzionalita) {
		this.siglaFunzionalita = siglaFunzionalita;
	}

	public String getNomeFunzionalita() {
		return nomeFunzionalita;
	}

	public void setNomeFunzionalita(String nomeFunzionalita) {
		this.nomeFunzionalita = nomeFunzionalita;
	}

	public Gruppo getGruppo() {
		return gruppo;
	}

	public void setGruppo(Gruppo gruppo) {
		this.gruppo = gruppo;
	}
	
	@Override
	public String toString(){
		return this.nomeFunzionalita + " " + this.siglaFunzionalita + " " + this.gruppo.getNomeGruppo() + "\n";
	}
}