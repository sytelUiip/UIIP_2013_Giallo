package it.gruppogiallo.entity;

import java.io.Serializable;

public class DTO  implements Serializable {

	private static final long serialVersionUID = 1L;
	private long id;
	
	public DTO(long id) {
		this.id = id;
	}

	public DTO() {

	}

	public void setId(long id) {
		this.id = id;
	}

	public long getId() {
		return id;
	}
}
