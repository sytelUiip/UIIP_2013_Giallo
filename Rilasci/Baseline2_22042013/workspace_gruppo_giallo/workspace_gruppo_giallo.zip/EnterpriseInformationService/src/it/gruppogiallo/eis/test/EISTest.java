package it.gruppogiallo.eis.test;

import it.gruppogiallo.dao.impl.SuperDAO;

import java.security.NoSuchAlgorithmException;

public class EISTest {

	public static void main(String[] args) throws NoSuchAlgorithmException {
		SuperDAO dao= new SuperDAO();
		System.out.println(dao.getAccountFromCredential("admin", "admin"));
	}

}
