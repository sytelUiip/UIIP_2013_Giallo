package it.gruppogiallo.connection;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class ConnectionManager {

	private static Properties connectionProperties = null;
	private static Connection conn = null;
	private static ConnectionManager instance = null;
	private static final Logger logger = Logger.getLogger(ConnectionManager.class);

	private ConnectionManager() {
		connectionProperties = new Properties();
		connect();
	}

	public static Connection getConnection() {
		if (instance == null)
			instance = new ConnectionManager();
		logger.debug("SINGLETON: ConnectionManager - "+" getConnection called in EIS");
		return conn;
	}

	private void loadConnectionConf() {
		
		Properties dbProps = new Properties();
		String in_filename = "connection.properties";
		InputStream is = getClass().getResourceAsStream("/" + in_filename);
		if (null == is) {
			logger.error("SINGLETON: ConnectionManager - method loadConnectionConf - "+" filename "+in_filename+" not exist ");
		}
		try {
			dbProps.load(is);
			connectionProperties = dbProps;
		} catch (IOException ioe) {
			logger.error("properties loading failed ");
            logger.error("filename "+in_filename+" not exist ");
            logger.error("Exception message:"+ioe.getMessage());
		}
	}

	private void connect() {
		loadConnectionConf();
		String connectionUrl = connectionProperties.getProperty("url")
				+ connectionProperties.getProperty("host") + ":"
				+ connectionProperties.getProperty("port") + ":"
				+ connectionProperties.getProperty("sid");
		try {
			Class.forName(connectionProperties.getProperty("driver"));
			conn = DriverManager.getConnection(connectionUrl,
					connectionProperties.getProperty("username"),
					connectionProperties.getProperty("password"));
			logger.info("Connected to: "+connectionUrl);
		} catch (ClassNotFoundException ex) {
			logger.error("Driver not found");
            logger.error("Exception message:"+ex.getMessage());
		} catch (SQLException ex) {
			logger.error("Connection Failed");
            logger.error("Exception message:"+ex.getMessage());
		}
	}
}