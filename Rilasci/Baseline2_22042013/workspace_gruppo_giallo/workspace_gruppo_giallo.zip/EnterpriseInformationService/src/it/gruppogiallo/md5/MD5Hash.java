package it.gruppogiallo.md5;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;

public class MD5Hash {

	private static final Logger logger = Logger.getLogger(MD5Hash.class);

	public static String generate(String toHash) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.reset();
		md.update(toHash.getBytes());
		BigInteger hash = new BigInteger(1, md.digest());
		logger.debug("Class: MD5Hash - "+" generated hashed string: "+hash.toString(32));
		return hash.toString(32); 		
	}
}
