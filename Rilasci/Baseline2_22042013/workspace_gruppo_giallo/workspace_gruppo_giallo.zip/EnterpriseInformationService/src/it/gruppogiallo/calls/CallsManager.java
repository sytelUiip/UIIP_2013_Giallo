package it.gruppogiallo.calls;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class CallsManager {

	private static Properties callsProperties = null;
	private static final Logger logger = Logger.getLogger(CallsManager.class);
	private static CallsManager instance = null;

	public CallsManager() {
		callsProperties = new Properties();
		loadClassConf();
	}
	
	public static Properties getCallsProperties() {
		if (instance == null)
			instance = new CallsManager();
		logger.debug("SINGLETON: CallsManager - "+" getCallsProperties called in EIS");
		return callsProperties;
	}
	
	private void loadClassConf() {
		
		Properties dbProps = new Properties();

        String in_filename = "calls.properties";
        InputStream is = getClass().getResourceAsStream("/"+in_filename );
        if(null == is) {
        	logger.error("SINGLETON: CallsManager - method loadClassConf - "+" filename "+in_filename+" not exist ");
        }
        try {
            dbProps.load(is);
            callsProperties = dbProps;
        }
        catch (IOException ioe) {
        	logger.error("properties loading failed ");
            logger.error("filename "+in_filename+" not exist ");
            logger.error("Exception message:"+ioe.getMessage());
        }
	}
}