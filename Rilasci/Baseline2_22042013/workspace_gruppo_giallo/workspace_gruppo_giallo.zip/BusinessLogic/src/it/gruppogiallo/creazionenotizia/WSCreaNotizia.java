package it.gruppogiallo.creazionenotizia;

public class WSCreaNotizia {

	public boolean creaNotizia(String loggedAccountUsername, String loggedAccountPassword, String titolo, String sottotitolo,
			String tipologiaNotizia, String autore,
			String testo) {
		// TODO Implementare creaNotizia nel WSCreaNotizia
		return false;
		//TODO Implementare un modo per ritornare un booleano controllato
	}
}
