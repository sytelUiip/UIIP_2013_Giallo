package it.gruppogiallo.cancellaaccount;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.security.Security;

import org.apache.log4j.Logger;

public class WSCancellaAccount {

	private SuperDAO dao;
	private static final Logger logger = Logger
			.getLogger(WSCancellaAccount.class);

	public boolean deleteAccount(String loggedAccountUsername, String loggedAccountPassword, String username) {
		logger.debug("WEBSERVICE: WSCancellaAccount - Service "
				+ " deleteAccount called in BL");
		boolean result = false;
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername, loggedAccountPassword, "CancellaAccount")) {
			if(!loggedAccountUsername.equals(username)){
				dao = new SuperDAO();
				result = dao.cancellaAccount(username);
			}
		}
		return result;
	}

}
