package it.gruppogiallo.registranotizia;

public class WSRegistraNotizia {

	public boolean registraNotizia(String loggedAccountUsername, String loggedAccountPassword, long id, String titolo, String sottotitolo,
			String testo, String tipologiaNotizia, String siglaGiornalista) {
		
		// Persistere le info sul database
		return false;
		// TODO Implementare un modo per ritornare un booleano controllato
	}
}
