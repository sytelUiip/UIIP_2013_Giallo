package it.gruppogiallo.moificaaccount;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Gruppo;
import it.gruppogiallo.security.Security;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class WSModificaAccount {
	private SuperDAO dao;
	private static final Logger logger = Logger
			.getLogger(WSModificaAccount.class);

	public boolean modificaAccount(String loggedAccountUsername,
			String loggedAccountPassword, String username, String nome,
			String cognome, String email, String siglaRedazione,
			String siglaGiornalista, String[] gruppi) {
		logger.debug("WEBSERVICE: WSModificaAccount - Service "
				+ " modificaAccount called in BL");
		boolean result = false;
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "ModificaAccount")) {
			dao = new SuperDAO();

			boolean gruppiModificati = false;
			boolean accountModificati = false;

			List<Gruppo> listaGruppi = new ArrayList<Gruppo>();
			for (int i = 0; i < gruppi.length; i++) {
				listaGruppi.add(new Gruppo(gruppi[i]));
			}

			gruppiModificati = dao.aggiornaAppartenenzaGruppo(username,
					listaGruppi);
			if (gruppiModificati)
				accountModificati = dao.modificaAccount(username, nome,
						cognome, email, siglaRedazione, siglaGiornalista);

			return gruppiModificati && accountModificati;
		}
		return result;
	}

}
