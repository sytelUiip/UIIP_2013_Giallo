package it.gruppogiallo.annullamodificanotizia;

public class WSAnnullaModificaNotizia {

	public boolean annullaModificaNotizia(String loggedAccountUsername,
			String loggedAccountPassword, long id, String siglaGiornalista) {
		return false;
	}

}
