package it.gruppogiallo.visualizzanotizia;

import it.gruppogiallo.entity.Notizia;

public class WSVisualizzaNotizia {

	public Notizia visualizzaNotizia(String loggedAccountUsername, String loggedAccountPassword) {
		//TODO Implementare visualizza Notizia
		return null;
	}
}
