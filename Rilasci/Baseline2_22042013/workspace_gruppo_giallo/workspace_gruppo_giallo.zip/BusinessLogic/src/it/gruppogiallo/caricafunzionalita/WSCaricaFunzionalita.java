package it.gruppogiallo.caricafunzionalita;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Funzionalita;

import java.util.List;

import org.apache.log4j.Logger;

public class WSCaricaFunzionalita {
	private SuperDAO dao;
	private static final Logger logger = Logger.getLogger(WSCaricaFunzionalita.class);
	public List<Funzionalita> carica(String username){
		logger.debug("WEBSERVICE: WSCaricaFunzionalita - Service "+" carica called in BL");
		dao = new SuperDAO();
		return dao.listaFunzionalitabyUsername(username);
	}
}
