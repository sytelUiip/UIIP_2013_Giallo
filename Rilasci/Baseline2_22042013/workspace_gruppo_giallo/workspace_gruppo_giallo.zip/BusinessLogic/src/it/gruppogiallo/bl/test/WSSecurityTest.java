package it.gruppogiallo.bl.test;

import it.gruppogiallo.security.Security;

public class WSSecurityTest {

	public static void main(String[] args) {
		Security sec = new Security();
		System.out.println(sec.getPermission("admin", "admin", "CancellaAccount"));
	}
}
