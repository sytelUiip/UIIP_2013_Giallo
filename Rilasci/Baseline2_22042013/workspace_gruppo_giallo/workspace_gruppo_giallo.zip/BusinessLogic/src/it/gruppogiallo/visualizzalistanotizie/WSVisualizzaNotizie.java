package it.gruppogiallo.visualizzalistanotizie;

import java.util.ArrayList;
import java.util.List;

import it.gruppogiallo.entity.Notizia;

public class WSVisualizzaNotizie {
	
	public List<Notizia> listaNotizie(String loggedAccountUsername, String loggedAccountPassword) {
		return new ArrayList<Notizia>();
	}	
	
	// Implementata questa funzionalit� per eventuali problemi con Axis2
	// sulla compatibilit� di List<E>
	public Notizia[] listaNotizieARRAY(String loggedAccountUsername, String loggedAccountPassword) {
		// TODO Implementare lista notizie!!!
		return new Notizia[1];
	}
}
