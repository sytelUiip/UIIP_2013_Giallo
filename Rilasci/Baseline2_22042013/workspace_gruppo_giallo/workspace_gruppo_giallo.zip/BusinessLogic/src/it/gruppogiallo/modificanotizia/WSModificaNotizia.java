package it.gruppogiallo.modificanotizia;

import it.gruppogiallo.entity.Notizia;

public class WSModificaNotizia {
	
	public Notizia modificaNotizia(String loggedAccountUsername, String loggedAccountPassword, long id, String siglaGiornalista) {
		
		// Settare in modo corretto il LOCK, STATO
		return null;
		// TODO Implementare un modo per ritornare un booleano controllato
	}
	
	public boolean puoModificare(long id, String siglaGiornalista) {
		
		return false;
		// TODO Implementare un modo per ritornare un booleano controllato
	}
}
