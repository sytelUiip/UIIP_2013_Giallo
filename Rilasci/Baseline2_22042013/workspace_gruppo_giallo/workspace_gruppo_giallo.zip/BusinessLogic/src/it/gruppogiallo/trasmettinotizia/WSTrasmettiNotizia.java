package it.gruppogiallo.trasmettinotizia;

public class WSTrasmettiNotizia {

	public boolean trasmettiNotizia(String loggedAccountUsername, String loggedAccountPassword, long id) {
		// TODO Implementare trasmetti notizia
		return false;
	}
}
