package it.gruppogiallo.cancellanotizia;

public class WSCancellaNotizia {

	public boolean cancellaNotizia(String loggedAccountUsername, String loggedAccountPassword, long id) {
		
		return false;
		//TODO Implementare un modo per ritornare un booleano controllato
	}
}
