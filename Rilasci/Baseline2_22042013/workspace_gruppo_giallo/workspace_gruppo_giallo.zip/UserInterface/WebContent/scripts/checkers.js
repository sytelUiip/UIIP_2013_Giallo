function checkLoginFields()
{
	var returntype=false;
    if( document.login.username.value.length<=0 )
    {
        alert('Completa il campo Username');
        document.login.username.focus();
    }
    else if( document.login.password.value.length<=0 )
    {
        alert('Completa il campo Password');
        document.login.password.focus();
    }
    else
    	returntype=true;
    
    return returntype;
}

function checkCreaAccountFields()
{
	var returntype=false;
	var test_email=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})$/;
	if( document.creaAccount.email.value.length<=0 )
    {
        alert('Inserisci la tua email');
        document.creaAccount.email.focus();
    }
     else if( !(test_email.test(document.creaAccount.email.value)))
    {
        alert('Inserire una email valida');
        document.creaAccount.email.focus();
    }
    else
    	 returntype=true;
	return returntype;
}
/*
function registrazione_check_fields()
{
	var test_email=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})$/;
	var test_numbers=/^([0-9]+)/;
	var codice=document.ins_registrazione.codice.value;
	var captchacode=document.getElementById('captchacode').innerText;
	if(document.ins_registrazione.accetto.checked==false)
	{
		alert("Devi autorizzare il trattamento ai dati personali")
		return false;
	}
	else if (codice != captchacode)
	{ 
		alert('Il codice CAPTCHA inserito non � uguale') 
		return false
	}
	else if(document.ins_registrazione.nome_attivita.value<=0)
	{
		alert('Completa tutti i campi con l\'asterisco');
		return false;
	}
	else if(document.ins_registrazione.nome.value<=0)
	{
		alert('Completa tutti i campi con l\'asterisco');
		return false;
	}
	else if(document.ins_registrazione.cognome.value<=0)
	{
		alert('Completa tutti i campi con l\'asterisco');
		return false;
	}
	else if(document.ins_registrazione.email.value<=0)
	{
		alert('Completa tutti i campi con l\'asterisco');
		return false;
	}
	else if(document.ins_registrazione.pi.value<=0)
	{
		alert('Per le aziende � necessario specificare Partita Iva');
		return false;
	}
	else if( !(test_numbers.test(document.ins_registrazione.tel.value)))
    {
        alert('Completa correttamente il campo Telefono');
        document.ins_registrazione.tel.focus();
        return false;
    }
    else if( !(test_numbers.test(document.ins_registrazione.cell.value)))
    {
        alert('Completa correttamente il campo campo Cellulare');
        document.ins_registrazione.cell.focus();
        return false;
    }
	else if( !(test_email.test(document.ins_registrazione.email.value)))
    {
        alert('Inserire una email valida');
        document.ins_registrazione.email.focus();
        return false;
    }
    else if(document.ins_registrazione.indirizzo.value<=0)
	{
		alert('Completa tutti i campi con l\'asterisco');
		return false;
	}
	else if(document.ins_registrazione.password.value<=0)
	{
		alert('Completa tutti i campi con l\'asterisco');
		return false;
	}   
	else if(document.ins_registrazione.c_password.value<=0)
	{
		alert('Completa tutti i campi con l\'asterisco');
		return false;
	}  
	else if(!((document.ins_registrazione.c_password.value)==(document.ins_registrazione.password.value)))
	{
		alert('Le due password non coincidono');
		return false;
	}  
	else {alert('tutto ok stranamente');return false;}
}

function ente_check_fields()
{
	var test_email=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})$/;
	var test_numbers=/^([0-9]+)/;
	var codice=document.ins_registrazione_ente.codice.value;
	var captchacode=document.getElementById('captchacode').innerText;
	if(document.ins_registrazione_ente.accetto.checked==false)
	{
		alert("Devi autorizzare il trattamento ai dati personali")
		return false;
	}
	else if (codice != captchacode)
	{ 
		alert('Il codice CAPTCHA inserito non � uguale') 
		return false
	}
	else if(document.ins_registrazione_ente.nome_attivita.value<=0)
	{
		focus(document.ins_registrazione_ente.nome_attivita);
		alert('Completa il nome Ente');
		return false;
	}
	else if(document.ins_registrazione_ente.nome.value<=0)
	{
		alert('Completa il tuo nome');
		return false;
	}
	else if(document.ins_registrazione_ente.cognome.value<=0)
	{
		alert('Completa il tuo cognome');
		return false;
	}
	else if(document.ins_registrazione_ente.email.value<=0)
	{
		alert('Completa la tua email');
		return false;
	}
	else if( !(test_numbers.test(document.ins_registrazione_ente.tel.value)))
    {
        alert('Completa correttamente il campo Telefono');
        document.ins_registrazione_ente.tel.focus();
        return false;
    }
    
	else if( !(test_email.test(document.ins_registrazione_ente.email.value)))
    {
        alert('Inserire una email valida');
        document.ins_registrazione_ente.email.focus();
        return false;
    }
    else if(document.ins_registrazione_ente.indirizzo.value<=0)
	{
		alert('Completa l\'indirizzo');
		return false;
	}
	else if(document.ins_registrazione_ente.password.value<=0)
	{
		alert('Inserisci una password');
		return false;
	}   
	else if(document.ins_registrazione_ente.c_password.value<=0)
	{
		alert('Completa tutti i campi password');
		return false;
	}  
	else if(!((document.ins_registrazione_ente.c_password.value)==(document.ins_registrazione_ente.password.value)))
	{
		alert('Le due password non coincidono');
		return false;
	}  
	else {alert('tutto ok stranamente');
	return false;}
}
*/