package it.gruppogiallo.caricafunzionalita;

import it.gruppogiallo.caricafunzionalita.WSCaricaFunzionalitaStub.Funzionalita;
import it.gruppogiallo.login.WSLoginStub.Account;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class CaricaFunzionalitaController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(CaricaFunzionalitaController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		logger.debug("Class CaricaFunzionalitaController - handleRequestInternal called in UI");

		WSCaricaFunzionalitaStub stub = new WSCaricaFunzionalitaStub();
		WSCaricaFunzionalitaStub.Carica carica = new WSCaricaFunzionalitaStub.Carica();
		Account account = (Account) request.getSession()
				.getAttribute("account");
		carica.setUsername(account.getUsername());
		WSCaricaFunzionalitaStub.CaricaResponse res = stub.carica(carica);
		Funzionalita[] funzionalita = res.get_return();
		List<Funzionalita> listaFunzionalita = new ArrayList<Funzionalita>();
		for (int i = 0; i < funzionalita.length; i++) {
			if (!(funzionalita[i].getNomeFunzionalita()
					.equals("CancellaAccount"))
					&& !(funzionalita[i].getNomeFunzionalita()
							.equals("ModificaAccount")))
				listaFunzionalita.add(funzionalita[i]);

		}

		return new ModelAndView("funzionalita", "listaFunzionalita",
				listaFunzionalita);
	}

}
