package it.gruppogiallo.ui.test;




import it.gruppogiallo.cancellaaccount.WSCancellaAccountStub;
import it.gruppogiallo.cancellaaccount.WSCancellaAccountStub.DeleteAccount;
import it.gruppogiallo.cancellaaccount.WSCancellaAccountStub.DeleteAccountResponse;

import java.rmi.RemoteException;

public class TestWSCancella {
	
	public static void main(String[] args) throws RemoteException {
		WSCancellaAccountStub stub = new WSCancellaAccountStub();
		WSCancellaAccountStub.DeleteAccount cancella = new WSCancellaAccountStub.DeleteAccount();
		cancella.setUsername("hansashi");
		WSCancellaAccountStub.DeleteAccountResponse res = stub.deleteAccount(cancella);
		Boolean bol = res.get_return();
		System.out.println(bol);
		
	}

}
