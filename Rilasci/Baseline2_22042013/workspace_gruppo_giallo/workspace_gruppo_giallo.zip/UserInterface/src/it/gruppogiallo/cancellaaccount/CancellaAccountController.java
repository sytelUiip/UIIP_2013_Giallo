package it.gruppogiallo.cancellaaccount;

import it.gruppogiallo.login.WSLoginStub.Account;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class CancellaAccountController extends AbstractController {
	
	private static final Logger logger = Logger.getLogger(CancellaAccountController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String courtesy;
		logger.debug("Class CancellaAccountController - handleRequestInternal called in UI");
		WSCancellaAccountStub stub = new WSCancellaAccountStub();
		WSCancellaAccountStub.DeleteAccount cancella = new WSCancellaAccountStub.DeleteAccount();
		Account loggedAccount = (Account) request.getSession().getAttribute("account");
		
		if(!loggedAccount.getUsername().equals(request.getParameter("username"))){
			cancella.setLoggedAccountUsername(loggedAccount.getUsername());
			cancella.setLoggedAccountPassword(loggedAccount.getPassword());
			cancella.setUsername(request.getParameter("username"));
			stub.deleteAccount(cancella);
			courtesy = "Cancellazione avvenuta con successo<br />";
		}
		else
			courtesy = "Non e' possibile eliminare il tuo stesso account<br />";
		
		return new ModelAndView("courtesyPage","message",courtesy);
	}

}
