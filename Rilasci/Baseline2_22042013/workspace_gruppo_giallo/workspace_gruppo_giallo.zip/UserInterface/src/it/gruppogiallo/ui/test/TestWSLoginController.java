package it.gruppogiallo.ui.test;

import it.gruppogiallo.login.WSLoginStub;

import java.rmi.RemoteException;

public class TestWSLoginController {

	public static void main(String[] args) throws RemoteException {
		WSLoginStub stub = new WSLoginStub();
		WSLoginStub.GetLogin login = new WSLoginStub.GetLogin();
		login.setUsername("admin");
		login.setPassword("admin");
		stub.getLogin(login);
	}

}
