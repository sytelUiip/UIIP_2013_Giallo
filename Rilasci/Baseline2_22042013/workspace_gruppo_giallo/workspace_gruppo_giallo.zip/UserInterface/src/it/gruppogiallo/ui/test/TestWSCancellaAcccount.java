package it.gruppogiallo.ui.test;

import it.gruppogiallo.creaaccount.WSCreaAccountStub;
import it.gruppogiallo.creaaccount.WSCreaAccountStub.Crea;
import it.gruppogiallo.creaaccount.WSCreaAccountStub.CreaResponse;

import java.rmi.RemoteException;

public class TestWSCancellaAcccount {

	/**
	 * @param args
	 * @throws RemoteException
	 */
	public static void main(String[] args) throws RemoteException {
		WSCreaAccountStub stub = new WSCreaAccountStub();
		WSCreaAccountStub.Crea crea = new WSCreaAccountStub.Crea();
		crea.setUsername("CinziaTheBest2");
		crea.setPassword("pass");
		crea.setNome("Cinzia");
		crea.setCognome("Tito");
		crea.setEmail("aaaa@gmail.com");
		crea.setSiglaGiornalista("cinzietta");
		crea.setSiglaRedazione("rep");
		WSCreaAccountStub.CreaResponse res = stub.crea(crea);
		Boolean bol = res.get_return();
		System.out.println(bol);
	}

}
