package it.gruppogiallo.visualizzalistaaccount;

import it.gruppogiallo.visualizzalistaaccount.WSVisualizzaAccountStub.Account;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class VisualizzaAccountController extends AbstractController {
	
	private static final Logger logger = Logger.getLogger(VisualizzaAccountController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		logger.debug("Class VisualizzaAccountController - handleRequestInternal called in UI");
		WSVisualizzaAccountStub stub = new WSVisualizzaAccountStub();
		WSVisualizzaAccountStub.VisualizzaAccount visualizza = new WSVisualizzaAccountStub.VisualizzaAccount();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request.getSession().getAttribute("account");
		visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
		visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
		WSVisualizzaAccountStub.VisualizzaAccountResponse res = stub.visualizzaAccount(visualizza);
		Account[] accounts = res.get_return();
		List<Account> listaAccount = new ArrayList<Account>();
		for(int i=0; i<accounts.length; i++){
			listaAccount.add(accounts[i]);
		}
		/*request.getSession().setAttribute("listaAccount", listaAccount);*/
		//return new ModelAndView("listaAccounts","accounts",listaAccount);
		return new ModelAndView("viewAccounts","accounts",listaAccount);
	}
}