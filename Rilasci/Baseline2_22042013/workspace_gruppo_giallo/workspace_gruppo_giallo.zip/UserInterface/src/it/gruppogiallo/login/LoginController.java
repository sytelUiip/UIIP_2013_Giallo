package it.gruppogiallo.login;

import it.gruppogiallo.login.WSLoginStub.Account;
import it.gruppogiallo.login.WSLoginStub.Gruppo;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class LoginController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(LoginController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.debug("Class LoginController - handleRequestInternal called in UI");
		logger.debug("Username: " + request.getParameter("username"));
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		boolean isAdmin = false;
		boolean isJournalist = false;

		String page = null;
		String parameter = null;

		if (username.equals("") || password.equals("")) {
			logger.warn("Class LoginController - no Username and Password fields");
			page = "login";
			parameter = "Completa tutti i campi";

		} else {
			WSLoginStub stub = new WSLoginStub();
			WSLoginStub.GetLogin login = new WSLoginStub.GetLogin();
			login.setUsername(request.getParameter("username"));
			login.setPassword(request.getParameter("password"));
			WSLoginStub.GetLoginResponse res = stub.getLogin(login);
			Account account = res.get_return();

			if (account == null) {
				logger.debug("Class LoginController - No account retrieve from DB");
				page = "login";
				parameter = "Account non trovato";
			} else {
				request.getSession().setAttribute("account", account);
				page = "home";
				Gruppo[] gruppi = account.getGruppi();
				for (int i = 0; i < gruppi.length; i++) {
					if (gruppi[i].getNomeGruppo().equalsIgnoreCase(
							"amministratore"))
						isAdmin = true;
					else
						isJournalist = true;
				}
				if (isAdmin) {
					logger.info("Admin " + username + " is logged on");
					request.getSession().setAttribute("isAdmin", "true");
					if (isJournalist) {
						parameter = "admin";
						request.getSession().setAttribute("work", "both");
					} else {
						parameter = "admin";
						request.getSession().setAttribute("work", "admin");
					}
				} else {
					parameter = "journalist";
					logger.info("Journalist " + username + " is logged on");
					request.getSession().setAttribute("isAdmin", "false");
					request.getSession().setAttribute("work", "journalist");
				}
			}
		}
		return new ModelAndView(page, "parameter", parameter);
	}
}
