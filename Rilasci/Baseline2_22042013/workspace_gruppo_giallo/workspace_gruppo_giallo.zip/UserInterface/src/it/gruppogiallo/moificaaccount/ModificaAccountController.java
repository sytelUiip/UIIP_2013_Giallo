package it.gruppogiallo.moificaaccount;

import it.gruppogiallo.login.WSLoginStub.Account;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class ModificaAccountController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(ModificaAccountController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String courtesyMessage = "";
		logger.debug("Class ModificaAccountController - handleRequestInternal called in UI");
		Account loggedAccount = (Account) request.getSession().getAttribute(
				"account");
		if (loggedAccount.getUsername().equals(
				request.getParameter("usernameModificato"))) {
			if (request.getParameter("primoGruppo") == null) {
				courtesyMessage = "Non puoi toglierti i diritti di amministrazione<br />";
			}
		} else {
			WSModificaAccountStub stub = new WSModificaAccountStub();
			WSModificaAccountStub.ModificaAccount modifica = new WSModificaAccountStub.ModificaAccount();
			modifica.setLoggedAccountUsername(loggedAccount.getUsername());
			modifica.setLoggedAccountPassword(loggedAccount.getPassword());
			modifica.setNome(request.getParameter("nome"));
			modifica.setCognome(request.getParameter("cognome"));
			modifica.setUsername(request.getParameter("usernameModificato"));
			modifica.setEmail(request.getParameter("email"));
			modifica.setSiglaRedazione(request.getParameter("siglaRedazione"));
			modifica.setSiglaGiornalista(request
					.getParameter("siglaGiornalista"));

			List<String> lista = new ArrayList<String>();

			if (request.getParameter("primoGruppo") != null
					&& request.getParameter("primoGruppo").equals("1")) {
				lista.add("AMMINISTRATORE");
			}
			if (request.getParameter("secondoGruppo") != null
					&& request.getParameter("secondoGruppo").equals("1")) {
				lista.add("GIORNALISTA");
			}

			String[] gruppi = new String[lista.size()];
			for (int i = 0; i < gruppi.length; i++)
				gruppi[i] = lista.get(i);

			modifica.setGruppi(gruppi);

			WSModificaAccountStub.ModificaAccountResponse res = stub
					.modificaAccount(modifica);
			boolean risultato = res.get_return();

			if (risultato)
				courtesyMessage = "Modifica account avvenuta con successo<br />";
			else
				courtesyMessage = "Errore nella modifica dell'account<br />";

			logger.debug("Account "
					+ request.getParameter("usernameModificato")
					+ " successfully modified");
			logger.info("Account " + request.getParameter("usernameModificato")
					+ " successfully modified");
		}
		return new ModelAndView("courtesyPage", "message", courtesyMessage);
	}

}
