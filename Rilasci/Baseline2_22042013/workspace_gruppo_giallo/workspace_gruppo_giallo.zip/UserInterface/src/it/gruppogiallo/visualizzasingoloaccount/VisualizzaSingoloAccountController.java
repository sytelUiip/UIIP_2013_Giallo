package it.gruppogiallo.visualizzasingoloaccount;

import it.gruppogiallo.visualizzasingoloaccount.WSVisualizzaSingoloAccountStub.Account;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class VisualizzaSingoloAccountController extends AbstractController {

	private static final Logger logger = Logger.getLogger(VisualizzaSingoloAccountController.class);
	
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		logger.debug("Class VisualizzaSingoloAccountController - handleRequestInternal called in UI");
		WSVisualizzaSingoloAccountStub stub = new WSVisualizzaSingoloAccountStub();
		WSVisualizzaSingoloAccountStub.Visualizza visualizza = new WSVisualizzaSingoloAccountStub.Visualizza();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request.getSession().getAttribute("account");
		visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
		visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
		visualizza.setUsername(request.getParameter("username"));
		WSVisualizzaSingoloAccountStub.VisualizzaResponse res = stub.visualizza(visualizza);
		Account account = res.get_return();
		request.getSession().removeAttribute("adminChecked");
		request.getSession().removeAttribute("journalistChecked");
		for(int i = 0; i<account.getGruppi().length;i++) {
			if(account.getGruppi()[i].getNomeGruppo().equals("AMMINISTRATORE")) {
				request.getSession().setAttribute("adminChecked", "checked='checked'");
			}
			if(account.getGruppi()[i].getNomeGruppo().equals("GIORNALISTA")) {
				request.getSession().setAttribute("journalistChecked", "checked='checked'");
			}
		}
		
		return new ModelAndView("modifica", "accountDaModificare", account);
	}

}
