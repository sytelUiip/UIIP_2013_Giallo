package it.gruppogiallo.creaaccount;

import java.rmi.RemoteException;
import java.util.Properties;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoPermissionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.login.WSLoginStub.Account;
import it.gruppogiallo.wsmanager.WSManager;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class CreaAccountController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(CreaAccountController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		logger.debug("Class CreaAccountController - handleRequestInternal called in UI");

		String courtesyMessage = "";
		try{
		String username = request.getParameter("username");
		String nome = request.getParameter("nome");
		String cognome = request.getParameter("cognome");
		String email = request.getParameter("email");
		String siglaGiornalista = request.getParameter("siglaGiornalista");
		String siglaRedazione = request.getParameter("siglaRedazione");
		String pass = PasswordGenerator.generatePwd();

		if (username.equals("") || nome.equals("") || cognome.equals("")
				|| email.equals("") || siglaGiornalista.equals("")
				|| siglaRedazione.equals("") || pass.equals(""))
			courtesyMessage = "messages.courtesy.fail.creaaccount";
		else {
			Properties wsManager = WSManager.getWSProperties();

			String serviceName = "WSCreaAccount";
			String wsEndpoint = "http://";
			wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
			wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
			wsEndpoint += wsManager.getProperty(serviceName + "-Base");
			wsEndpoint += "/services/" + serviceName + "." + serviceName
					+ "HttpSoap12Endpoint/";

			WSCreaAccountStub stub = new WSCreaAccountStub(null, wsEndpoint);
			WSCreaAccountStub.Crea crea = new WSCreaAccountStub.Crea();
			Account loggedAccount = (Account) request.getSession()
					.getAttribute("account");
			crea.setLoggedAccountUsername(loggedAccount.getUsername());
			crea.setLoggedAccountPassword(loggedAccount.getPassword());
			crea.setNome(request.getParameter("nome"));
			crea.setCognome(request.getParameter("cognome"));
			crea.setEmail(request.getParameter("email"));
			crea.setUsername(request.getParameter("username"));
			crea.setPassword(pass);
			crea.setSiglaGiornalista(request.getParameter("siglaGiornalista"));
			crea.setSiglaRedazione(request.getParameter("siglaRedazione"));
			try {
				WSCreaAccountStub.CreaResponse res = stub.crea(crea);
				Boolean bol = res.get_return();

				if (bol) {
					Context initCtx = new InitialContext();
					Context envCtx = (Context) initCtx.lookup("java:comp/env");
					Session sessione = (Session) envCtx.lookup("mail/Session");

					Message message = new MimeMessage(sessione);
					InternetAddress toe[] = new InternetAddress[1];
					toe[0] = new InternetAddress(email);
					message.setRecipients(Message.RecipientType.TO, toe);
					message.setSubject("Avvenuta Registrazione");
					String messageMail = "Ciao " + nome + " " + cognome
							+ ",\n\n";
					messageMail += "Ti confermiamo la avvenuta registrazione su TheYellowDaily.\n";
					messageMail += "Di seguito sono riportati i dati per accedere alla tua area riservata e utilizzare i servizi online:\n\n";
					messageMail += "Username: " + username + "\n Password: "
							+ pass;
					messageMail += "\n\nLo staff TheYellowDaily";
					message.setContent(messageMail, "text/plain");
					Transport.send(message);
					courtesyMessage = "messages.courtesy.success.creaaccount";

					logger.debug("eMail sent to "
							+ request.getParameter("username"));
				} else {
					courtesyMessage = "messages.courtesy.fail.creaaccount";
					logger.debug("eMail not sent to "
							+ request.getParameter("username"));
				}
			} catch (RemoteException e) {
				if (e.getMessage().equals("100")) {
					throw new NoDBConnectionException();
				} else {
					throw new NoWSConnectionException(stub.getClass());
				}
			}
		}
		}
		catch(NullPointerException np){
			throw new NoPermissionException();
		}
		return new ModelAndView("courtesyPage", "message", courtesyMessage);
	}

}
