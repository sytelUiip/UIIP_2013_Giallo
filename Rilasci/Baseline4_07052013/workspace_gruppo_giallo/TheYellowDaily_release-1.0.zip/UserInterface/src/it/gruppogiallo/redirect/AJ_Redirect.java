package it.gruppogiallo.redirect;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoPermissionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.visualizzalistanotizie.WSVisualizzaNotizieStub;
import it.gruppogiallo.visualizzalistanotizie.WSVisualizzaNotizieStub.Notizia;
import it.gruppogiallo.wsmanager.WSManager;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class AJ_Redirect extends AbstractController {
	private static final Logger logger = Logger
			.getLogger(AJ_Redirect.class);
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String parameter=null;
		try {
			if (request.getSession().getAttribute("isAdmin").equals("true")
					|| request.getSession().getAttribute("isAdmin").equals("both")) {
				parameter = "admin";
			} else {
				parameter = "journalist";
			}	
		} catch(NullPointerException npe) {
			logger.info("REDIRECT AJ_Redirect - account not logged");
		}
		List<Notizia> listaNotizie = new ArrayList<Notizia>();

		logger.debug("Class VisualizzaNotizieController - handleRequestInternal called in UI");

		Properties wsManager = WSManager.getWSProperties();

		String serviceName = "WSVisualizzaNotizie";
		String wsEndpoint = "http://";
		wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
		wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
		wsEndpoint += wsManager.getProperty(serviceName + "-Base");
		wsEndpoint += "/services/" + serviceName + "." + serviceName
				+ "HttpSoap12Endpoint/";

		WSVisualizzaNotizieStub stub = new WSVisualizzaNotizieStub(null,
				wsEndpoint);
		WSVisualizzaNotizieStub.RicercaNotiziePerAutore visualizza = new WSVisualizzaNotizieStub.RicercaNotiziePerAutore();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request
				.getSession().getAttribute("account");
		try {
		visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
		visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
		} catch (NullPointerException npe) {
			throw new NoPermissionException();
		}
		int minLimit = 0, maxLimit = Integer.MAX_VALUE;
		visualizza.setMinLimit(minLimit);
		visualizza.setMaxLimit(maxLimit);
		visualizza.setAutore(loggedAccount.getSiglaGiornalista());
		WSVisualizzaNotizieStub.RicercaNotiziePerAutoreResponse res = null;
		try {
			res = stub.ricercaNotiziePerAutore(visualizza);
		} catch (RemoteException e) {
			if (e.getMessage().equals("100")) {
				throw new NoDBConnectionException();
			} else {
				throw new NoWSConnectionException(stub.getClass());
			}
		}

		Notizia[] notizie = res.get_return();
		if (notizie == null) {
			logger.warn("No news to show in JSP");
		} else {
			for (int i = 0; i < notizie.length; i++) {
				listaNotizie.add(notizie[i]);
			}
		}
		return new ModelAndView(parameter,"notizie",listaNotizie);
	}

}
