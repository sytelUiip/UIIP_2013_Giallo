package it.gruppogiallo.visualizzalistaaccount;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoPermissionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.visualizzalistaaccount.WSVisualizzaAccountStub.Account;
import it.gruppogiallo.wsmanager.WSManager;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class VisualizzaAccountController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(VisualizzaAccountController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		logger.debug("Class VisualizzaAccountController - handleRequestInternal called in UI");

		Properties wsManager = WSManager.getWSProperties();

		String serviceName = "WSVisualizzaAccount";
		String wsEndpoint = "http://";
		wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
		wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
		wsEndpoint += wsManager.getProperty(serviceName + "-Base");
		wsEndpoint += "/services/" + serviceName + "." + serviceName
				+ "HttpSoap12Endpoint/";

		WSVisualizzaAccountStub stub = new WSVisualizzaAccountStub(null,
				wsEndpoint);
		WSVisualizzaAccountStub.VisualizzaAccount visualizza = new WSVisualizzaAccountStub.VisualizzaAccount();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request
				.getSession().getAttribute("account");
		try {
			visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
			visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
			
		} catch (NullPointerException npt) {
			throw new NoPermissionException();
		}
		WSVisualizzaAccountStub.VisualizzaAccountResponse res = null;
		try {
			res = stub.visualizzaAccount(visualizza);
		} catch (RemoteException e) {
			if (e.getMessage().equals("100")) {
				throw new NoDBConnectionException();
			} else {
				throw new NoWSConnectionException(stub.getClass());
			}
		}

		Account[] accounts = res.get_return();
		List<Account> listaAccount = new ArrayList<Account>();
		for (int i = 0; i < accounts.length; i++) {
			listaAccount.add(accounts[i]);
		}
		/* request.getSession().setAttribute("listaAccount", listaAccount); */
		// return new ModelAndView("listaAccounts","accounts",listaAccount);
		return new ModelAndView("viewAccounts", "accounts", listaAccount);
	}
}