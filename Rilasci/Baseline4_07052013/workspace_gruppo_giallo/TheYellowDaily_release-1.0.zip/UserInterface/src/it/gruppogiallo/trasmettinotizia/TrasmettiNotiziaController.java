package it.gruppogiallo.trasmettinotizia;

import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.gruppogiallo.exception.NoPermissionException;
import it.gruppogiallo.visualizzanotizia.WSVisualizzaNotiziaStub;
import it.gruppogiallo.visualizzanotizia.WSVisualizzaNotiziaStub.Notizia;
import it.gruppogiallo.wsmanager.WSManager;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class TrasmettiNotiziaController extends AbstractController {
	private static final Logger logger = Logger
			.getLogger(TrasmettiNotiziaController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String courtesy;
		logger.debug("Class TrasmettiNotiziaController - handleRequestInternal called in UI");
		WSVisualizzaNotiziaStub stubVisNotizia = new WSVisualizzaNotiziaStub();
		WSVisualizzaNotiziaStub.VisualizzaNotizia visualizza = new WSVisualizzaNotiziaStub.VisualizzaNotizia();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request
				.getSession().getAttribute("account");

		try{
		visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
		visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
		visualizza.setId(Long.parseLong(request.getParameter("id")));
		}
		catch(NullPointerException np){
			throw new NoPermissionException();
		}
		WSVisualizzaNotiziaStub.VisualizzaNotiziaResponse resVisualizza = stubVisNotizia
				.visualizzaNotizia(visualizza);
		Notizia notizia = new Notizia();
		notizia = resVisualizza.get_return();

		if (!(notizia.getStato().equals("S")))
			courtesy = "messages.courtesy.fail.trasmettinotizia";
		else {
			if ((notizia.getLockNotizia().equals("Y"))
					&& (!(loggedAccount.getSiglaGiornalista().equals(notizia
							.getUltimoDigitatore())))) {
				courtesy = "messages.courtesy.fail.noaccess.trasmettinotizia";

			} else {
				Properties wsManager = WSManager.getWSProperties();

				String serviceName = "WSTrasmettiNotizia";
				String wsEndpoint = "http://";
				wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
				wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
				wsEndpoint += wsManager.getProperty(serviceName + "-Base");
				wsEndpoint += "/services/" + serviceName + "." + serviceName
						+ "HttpSoap12Endpoint/";
				WSTrasmettiNotiziaStub stub = new WSTrasmettiNotiziaStub(null, wsEndpoint);
				WSTrasmettiNotiziaStub.TrasmettiNotizia trasmetti = new WSTrasmettiNotiziaStub.TrasmettiNotizia();
				trasmetti.setLoggedAccountUsername(loggedAccount.getUsername());
				trasmetti.setLoggedAccountPassword(loggedAccount.getPassword());
				trasmetti.setId(Long.parseLong(request.getParameter("id")));
				WSTrasmettiNotiziaStub.TrasmettiNotiziaResponse res = stub
						.trasmettiNotizia(trasmetti);
				res.get_return();
				courtesy = "messages.courtesy.success.trasmettinotizia";
			}

		}
		return new ModelAndView("courtesyPage", "message", courtesy);
	}

}
