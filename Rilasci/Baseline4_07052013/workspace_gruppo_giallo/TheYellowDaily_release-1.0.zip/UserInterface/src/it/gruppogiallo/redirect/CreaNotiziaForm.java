package it.gruppogiallo.redirect;

import it.gruppogiallo.exception.NoPermissionException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class CreaNotiziaForm extends AbstractController {

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.debug("REDIRECT CreaNotiziaForm - handleRequestInternal called in UI");
		if(request.getSession().getAttribute("account")==null)
			throw new NoPermissionException();
		return new ModelAndView("CreaNotiziaForm");
	}

}
