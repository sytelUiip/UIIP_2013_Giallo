package it.gruppogiallo.redirect;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class WelcomeRedirect extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(WelcomeRedirect.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.debug("REDIRECT WelcomeRedirect - handleRequestInternal called in UI");
		

		return new ModelAndView("home","parameter","welcome");
	}

}
