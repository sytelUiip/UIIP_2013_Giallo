package it.gruppogiallo.cancellaaccount;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoPermissionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.login.WSLoginStub.Account;
import it.gruppogiallo.wsmanager.WSManager;

import java.rmi.RemoteException;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class CancellaAccountController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(CancellaAccountController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String courtesy;
		logger.debug("Class CancellaAccountController - handleRequestInternal called in UI");

		Properties wsManager = WSManager.getWSProperties();

		String serviceName = "WSCancellaAccount";
		String wsEndpoint = "http://";
		wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
		wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
		wsEndpoint += wsManager.getProperty(serviceName + "-Base");
		wsEndpoint += "/services/" + serviceName + "." + serviceName
				+ "HttpSoap12Endpoint/";

		WSCancellaAccountStub stub = new WSCancellaAccountStub(null, wsEndpoint);
		WSCancellaAccountStub.DeleteAccount cancella = new WSCancellaAccountStub.DeleteAccount();
		Account loggedAccount = (Account) request.getSession().getAttribute(
				"account");

		try{
		if (!loggedAccount.getUsername().equals(
				request.getParameter("username"))) {
			cancella.setLoggedAccountUsername(loggedAccount.getUsername());
			cancella.setLoggedAccountPassword(loggedAccount.getPassword());
			cancella.setUsername(request.getParameter("username"));
			try {
				stub.deleteAccount(cancella);
				courtesy = "messages.courtesy.success.cancellaaccount";
			} catch (RemoteException e) {
				if (e.getMessage().equals("100")) {
					throw new NoDBConnectionException();
				} else {
					throw new NoWSConnectionException(stub.getClass());
				}
			}
		} else
			courtesy = "messages.courtesy.fail.cancellaaccount";
		}
		catch(NullPointerException np){
			throw new NoPermissionException();
		}
		return new ModelAndView("courtesyPage", "message", courtesy);
	}

}
