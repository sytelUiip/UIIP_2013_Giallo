package it.gruppogiallo.ui.test;

import it.gruppogiallo.visualizzalistaaccount.WSVisualizzaAccountStub;
import it.gruppogiallo.visualizzalistaaccount.WSVisualizzaAccountStub.Account;
import it.gruppogiallo.visualizzalistaaccount.WSVisualizzaAccountStub.VisualizzaAccount;
import it.gruppogiallo.visualizzalistaaccount.WSVisualizzaAccountStub.VisualizzaAccountResponse;

import java.rmi.RemoteException;

public class TestWSVisualizzaAccount {
	
	public static void main(String[] args) throws RemoteException {
		WSVisualizzaAccountStub stub = new WSVisualizzaAccountStub();
		WSVisualizzaAccountStub.VisualizzaAccount visualizza = new WSVisualizzaAccountStub.VisualizzaAccount();
		WSVisualizzaAccountStub.VisualizzaAccountResponse res = stub.visualizzaAccount(visualizza);
		
		Account[] accounts = res.get_return();
		for(int i=0; i<accounts.length; i++){
			System.out.println(accounts[i].getNome()+" "+accounts[i].getCognome() + " " + accounts[i].getEmail()  + " " + accounts[i].getSiglaGiornalista() + " " + accounts[i].getSiglaRedazione());
		}
	}
}
