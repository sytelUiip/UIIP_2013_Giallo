package it.gruppogiallo.visualizzasingoloaccount;

import java.rmi.RemoteException;
import java.util.Properties;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoPermissionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.visualizzasingoloaccount.WSVisualizzaSingoloAccountStub.Account;
import it.gruppogiallo.wsmanager.WSManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class VisualizzaSingoloAccountController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(VisualizzaSingoloAccountController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		logger.debug("Class VisualizzaSingoloAccountController - handleRequestInternal called in UI");

		Properties wsManager = WSManager.getWSProperties();

		String serviceName = "WSVisualizzaSingoloAccount";
		String wsEndpoint = "http://";
		wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
		wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
		wsEndpoint += wsManager.getProperty(serviceName + "-Base");
		wsEndpoint += "/services/" + serviceName + "." + serviceName
				+ "HttpSoap12Endpoint/";
		WSVisualizzaSingoloAccountStub stub = new WSVisualizzaSingoloAccountStub(
				null, wsEndpoint);
		WSVisualizzaSingoloAccountStub.Visualizza visualizza = new WSVisualizzaSingoloAccountStub.Visualizza();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request
				.getSession().getAttribute("account");
		try{
		visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
		visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
		visualizza.setUsername(request.getParameter("username"));
		}
		catch(NullPointerException np){
			throw new NoPermissionException();
		}
		WSVisualizzaSingoloAccountStub.VisualizzaResponse res = null;
		try {
			res = stub.visualizza(visualizza);
		} catch (RemoteException e) {
			if (e.getMessage().equals("100")) {
				throw new NoDBConnectionException();
			} else {
				throw new NoWSConnectionException(stub.getClass());
			}
		}

		Account account = res.get_return();
		request.getSession().removeAttribute("adminChecked");
		request.getSession().removeAttribute("journalistChecked");
		for (int i = 0; i < account.getGruppi().length; i++) {
			if (account.getGruppi()[i].getNomeGruppo().equals("AMMINISTRATORE")) {
				request.getSession().setAttribute("adminChecked",
						"checked='checked'");
			}
			if (account.getGruppi()[i].getNomeGruppo().equals("GIORNALISTA")) {
				request.getSession().setAttribute("journalistChecked",
						"checked='checked'");
			}
		}

		return new ModelAndView("modifica", "accountDaModificare", account);
	}

}
