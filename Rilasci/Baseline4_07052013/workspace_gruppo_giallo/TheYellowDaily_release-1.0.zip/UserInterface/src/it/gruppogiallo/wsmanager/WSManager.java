package it.gruppogiallo.wsmanager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class WSManager {

	private static Properties wsProperties = null;
	private static final Logger logger = Logger.getLogger(WSManager.class);
	private static WSManager instance = null;

	public WSManager() {
		wsProperties = new Properties();
		writeConnectionPropertiesFile();
		loadClassConf();
	}

	public static Properties getWSProperties() {
		if (instance == null)
			instance = new WSManager();
		logger.debug("SINGLETON: WSManager - getWSProperties called in UserInterface");
		return wsProperties;
	}

	private void loadClassConf() {
		Properties wsProps = new Properties();
		String in_filename = "webservices.properties";
		FileInputStream is=null;
		try {
			is = new FileInputStream("C:/theyellowdaily/conf/"+in_filename);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		if (null == is) {
			logger.error("SINGLETON: WSManager - method loadClassConf - "
					+ " filename " + in_filename + " not exist ");
		}
		try {
			wsProps.load(is);
			wsProperties = wsProps;
		} catch (IOException ioe) {
			logger.error("properties loading failed ");
			logger.error("filename " + in_filename + " not exist ");
			logger.error("Exception message:" + ioe.getMessage());
		}
	}
	
	private void writeConnectionPropertiesFile() {
		String folder = "C:/theyellowdaily/conf";
		new File(folder).mkdir();
		Properties wsProps = new Properties();
		String in_filename = "webservices.properties";
		File f= new File(folder+"/"+in_filename);
		InputStream is = getClass().getResourceAsStream("/" + in_filename);
		try {
			wsProps.load(is);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		try {
			if(f.createNewFile()) {
				try {
					FileOutputStream fos = new FileOutputStream(f);
					wsProps.store(fos, "Web Services Properties of The Yellow Daily");
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
}