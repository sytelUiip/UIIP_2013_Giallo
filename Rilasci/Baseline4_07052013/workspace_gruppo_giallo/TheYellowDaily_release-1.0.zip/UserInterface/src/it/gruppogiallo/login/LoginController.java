package it.gruppogiallo.login;

import java.rmi.RemoteException;
import java.util.Properties;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoPermissionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.login.WSLoginStub.Account;
import it.gruppogiallo.login.WSLoginStub.Gruppo;
import it.gruppogiallo.wsmanager.WSManager;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class LoginController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(LoginController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		logger.debug("Class LoginController - handleRequestInternal called in UI");
		logger.debug("Username: " + request.getParameter("username"));
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		boolean isAdmin = false;
		boolean isJournalist = false;

		String page = null;
		String parameter = null;

		try{
		
			if (username.equals("") || password.equals("")) {
				logger.warn("Class LoginController - no Username and Password fields");
				page = "login";
				parameter = "Completa tutti i campi";

			} else {

				Properties wsManager = WSManager.getWSProperties();

				String serviceName = "WSLogin";
				String wsEndpoint = "http://";
				wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
				wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
				wsEndpoint += wsManager.getProperty(serviceName + "-Base");
				wsEndpoint += "/services/" + serviceName + "." + serviceName
						+ "HttpSoap12Endpoint/";

				WSLoginStub stub = new WSLoginStub(null, wsEndpoint);

				WSLoginStub.GetLogin login = new WSLoginStub.GetLogin();
				login.setUsername(request.getParameter("username"));
				login.setPassword(request.getParameter("password"));
				WSLoginStub.GetLoginResponse res = null;
				try {
					res = stub.getLogin(login);
				} catch (RemoteException e) {
					if (e.getMessage().equals("100")) {
						throw new NoDBConnectionException();
					} else {
						throw new NoWSConnectionException(stub.getClass());
					}
				}
				Account account = res.get_return();

				if (account == null) {
					logger.debug("Class LoginController - No account retrieve from DB");
					page = "login";
					parameter = "Account non trovato";
				} else {
					request.getSession().setAttribute("account", account);
					page = "home";
					parameter = "postLogin";
					Gruppo[] gruppi = account.getGruppi();
					for (int i = 0; i < gruppi.length; i++) {
						if (gruppi[i].getNomeGruppo().equalsIgnoreCase(
								"amministratore"))
							isAdmin = true;
						else
							isJournalist = true;
					}
					if (isAdmin) {
						logger.info("Admin " + username + " is logged on");
						request.getSession().setAttribute("isAdmin", "true");
						if (isJournalist) {
							request.getSession().setAttribute("work", "both");
						} else {
							request.getSession().setAttribute("work", "admin");
						}
					} else {
						logger.info("Journalist " + username + " is logged on");
						request.getSession().setAttribute("isAdmin", "false");
						request.getSession().setAttribute("work", "journalist");
					}
				}
			}
		}
		catch(NullPointerException nopm){
			throw new NoPermissionException();
		}
				return new ModelAndView(page, "parameter", parameter);
	}
}
