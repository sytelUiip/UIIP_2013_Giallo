package it.gruppogiallo.caricafunzionalita;

import it.gruppogiallo.caricafunzionalita.WSCaricaFunzionalitaStub.Funzionalita;
import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoPermissionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.login.WSLoginStub.Account;
import it.gruppogiallo.wsmanager.WSManager;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class CaricaFunzionalitaController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(CaricaFunzionalitaController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		logger.debug("Class CaricaFunzionalitaController - handleRequestInternal called in UI");
		List<Funzionalita> listaFunzionalita = null;
		Properties wsManager = WSManager.getWSProperties();

		String serviceName = "WSCaricaFunzionalita";
		String wsEndpoint = "http://";
		wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
		wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
		wsEndpoint += wsManager.getProperty(serviceName + "-Base");
		wsEndpoint += "/services/" + serviceName + "." + serviceName
				+ "HttpSoap12Endpoint/";

		WSCaricaFunzionalitaStub stub = new WSCaricaFunzionalitaStub(null,
				wsEndpoint);
		WSCaricaFunzionalitaStub.Carica carica = new WSCaricaFunzionalitaStub.Carica();
		Account account = (Account) request.getSession()
				.getAttribute("account");

		try{
		carica.setUsername(account.getUsername());
		}
		catch(NullPointerException np){
			throw new NoPermissionException();
		}
		WSCaricaFunzionalitaStub.CaricaResponse res = null;
		try {
			res = stub.carica(carica);
		} catch (RemoteException e) {
			if (e.getMessage().equals("100")) {
				throw new NoDBConnectionException();
			} else {
				throw new NoWSConnectionException(stub.getClass());
			}
		}

		Funzionalita[] funzionalita = res.get_return();
		listaFunzionalita = new ArrayList<Funzionalita>();
		for (int i = 0; i < funzionalita.length; i++) {
			if (!(funzionalita[i].getNomeFunzionalita()
					.equals("CancellaAccount"))
					&& !(funzionalita[i].getNomeFunzionalita()
							.equals("ModificaAccount"))
					&& !(funzionalita[i].getNomeFunzionalita()
							.equals("ModificaNotizia"))
					&& !(funzionalita[i].getNomeFunzionalita()
							.equals("RegistraNotizia"))
					&& !(funzionalita[i].getNomeFunzionalita()
							.equals("CancellazioneNotizia"))
					&& !(funzionalita[i].getNomeFunzionalita()
							.equals("TrasmettiNotizia"))
					&& !(funzionalita[i].getNomeFunzionalita()
							.equals("VisualizzaNotizia"))
					&& !(funzionalita[i].getNomeFunzionalita()
							.equals("Annulla")))
				listaFunzionalita.add(funzionalita[i]);

		}

		return new ModelAndView("funzionalita", "listaFunzionalita",
				listaFunzionalita);
	}

}
