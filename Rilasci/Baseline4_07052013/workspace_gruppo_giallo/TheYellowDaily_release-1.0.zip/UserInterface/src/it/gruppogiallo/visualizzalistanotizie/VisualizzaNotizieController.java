package it.gruppogiallo.visualizzalistanotizie;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoPermissionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.visualizzalistanotizie.WSVisualizzaNotizieStub.Notizia;
import it.gruppogiallo.wsmanager.WSManager;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class VisualizzaNotizieController extends AbstractController {

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		boolean search = false;

		List<Notizia> listaNotizie = new ArrayList<Notizia>();

		logger.debug("Class VisualizzaNotizieController - handleRequestInternal called in UI");

		Properties wsManager = WSManager.getWSProperties();

		String serviceName = "WSVisualizzaNotizie";
		String wsEndpoint = "http://";
		wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
		wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
		wsEndpoint += wsManager.getProperty(serviceName + "-Base");
		wsEndpoint += "/services/" + serviceName + "." + serviceName
				+ "HttpSoap12Endpoint/";

		WSVisualizzaNotizieStub stub = new WSVisualizzaNotizieStub(null,
				wsEndpoint);
		WSVisualizzaNotizieStub.ListaNotizie visualizza = new WSVisualizzaNotizieStub.ListaNotizie();
		WSVisualizzaNotizieStub.RicercaNotiziePerAutore perAutore = new WSVisualizzaNotizieStub.RicercaNotiziePerAutore();
		WSVisualizzaNotizieStub.RicercaNotiziePerStato perStato = new WSVisualizzaNotizieStub.RicercaNotiziePerStato();
		WSVisualizzaNotizieStub.RicercaNotiziePerTitolo perTitolo = new WSVisualizzaNotizieStub.RicercaNotiziePerTitolo();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request
				.getSession().getAttribute("account");
		try{
		visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
		visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
		perAutore.setLoggedAccountUsername(loggedAccount.getUsername());
		perAutore.setLoggedAccountPassword(loggedAccount.getPassword());
		perStato.setLoggedAccountUsername(loggedAccount.getUsername());
		perStato.setLoggedAccountPassword(loggedAccount.getPassword());
		perTitolo.setLoggedAccountUsername(loggedAccount.getUsername());
		perTitolo.setLoggedAccountPassword(loggedAccount.getPassword());
		}
		catch(NullPointerException npt){
			throw new NoPermissionException();
		}
		int minLimit = 0, maxLimit = Integer.MAX_VALUE;

		if (request.getParameter("numeroNotizie") != null) {
			request.getSession().setAttribute("rowPerPage",
					request.getParameter("numeroNotizie"));
		} else {
			request.getSession().setAttribute("rowPerPage", "6");
		}

		if (request.getParameter("ricercaConCampi") != null) {

			if (!(request.getParameter("da").equals(""))) {
				minLimit = Integer.parseInt(request.getParameter("da"));
			}
			if (!(request.getParameter("a").equals(""))) {
				maxLimit = Integer.parseInt(request.getParameter("a"));
			}
			if (!request.getParameter("searchType").equals("all")) {
				if (request.getParameter("searchType").equals("autore")) {
					search = true;
					perAutore.setAutore(request.getParameter("ricerca-autore"));
					perAutore.setMinLimit(minLimit);
					perAutore.setMaxLimit(maxLimit);
					WSVisualizzaNotizieStub.RicercaNotiziePerAutoreResponse resp = stub
							.ricercaNotiziePerAutore(perAutore);
					Notizia[] notizieCercate = resp.get_return();
					if (notizieCercate != null) {
						for (int i = 0; i < notizieCercate.length; i++) {
							listaNotizie.add(notizieCercate[i]);
						}
					}
				}
				if (request.getParameter("searchType").equals("titolo")) {
					search = true;
					String[] words = request.getParameter("ricerca-titolo")
							.split(" ");
					List<Notizia> tempNotizie = new ArrayList<Notizia>();
					for (int k = 0; k < words.length; k++) {
						perTitolo.setTitolo(words[k]);
						perTitolo.setMinLimit(minLimit);
						perTitolo.setMaxLimit(maxLimit);
						WSVisualizzaNotizieStub.RicercaNotiziePerTitoloResponse resp = stub
								.ricercaNotiziePerTitolo(perTitolo);
						Notizia[] notizieCercate = resp.get_return();
						if (notizieCercate != null) {
							for (int i = 0; i < notizieCercate.length; i++) {
								tempNotizie.add(notizieCercate[i]);
							}
						}
					}
					Set<Long> id = new HashSet<Long>();
					for(Notizia n : tempNotizie){
						id.add(n.getId());
					}
					for(Notizia n : tempNotizie){
						if(id.contains(n.getId())){
							listaNotizie.add(n);
							id.remove(n.getId());
						}
					}
				}
				if (request.getParameter("searchType").equals("stato")) {
					search = true;
					perStato.setStato(request.getParameter("ricerca-stato"));
					perStato.setMinLimit(minLimit);
					perStato.setMaxLimit(maxLimit);
					WSVisualizzaNotizieStub.RicercaNotiziePerStatoResponse resp = stub
							.ricercaNotiziePerStato(perStato);
					Notizia[] notizieCercate = resp.get_return();
					if (notizieCercate != null) {
						for (int i = 0; i < notizieCercate.length; i++) {
							listaNotizie.add(notizieCercate[i]);
						}
					}
				}
			}
		}

		if (!search) {
			visualizza.setMinLimit(minLimit);
			visualizza.setMaxLimit(maxLimit);
			WSVisualizzaNotizieStub.ListaNotizieResponse res = null;
			try {
				res = stub.listaNotizie(visualizza);
			} catch (RemoteException e) {
				if (e.getMessage().equals("100")) {
					throw new NoDBConnectionException();
				} else {
					throw new NoWSConnectionException(stub.getClass());
				}
			}

			Notizia[] notizie = res.get_return();
			if (notizie == null) {
				logger.warn("No news to preview for admin");
			} else {
				for (int i = 0; i < notizie.length; i++) {
					listaNotizie.add(notizie[i]);
				}
			}
		}

		return new ModelAndView("viewNotizie", "notizie", listaNotizie);

	}

}
