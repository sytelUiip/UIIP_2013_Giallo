package it.gruppogiallo.sbloccanotizie;

import it.gruppogiallo.exception.NoPermissionException;
import it.gruppogiallo.wsmanager.WSManager;

import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class SbloccaNotizieController extends AbstractController{

	private static final Logger logger = Logger
			.getLogger(SbloccaNotizieController.class);
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String courtesy;
		Properties wsManager = WSManager.getWSProperties();

		String serviceName = "WSSbloccaNotizie";
		String wsEndpoint = "http://";
		wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
		wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
		wsEndpoint += wsManager.getProperty(serviceName + "-Base");
		wsEndpoint += "/services/" + serviceName + "." + serviceName
				+ "HttpSoap12Endpoint/";
		logger.debug("Class SbloccaNotizieController - handleRequestInternal called in UI");
		WSSbloccaNotizieStub stub=new WSSbloccaNotizieStub(null, wsEndpoint);
		WSSbloccaNotizieStub.SbloccaNotizie sblocca= new WSSbloccaNotizieStub.SbloccaNotizie();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request
				.getSession().getAttribute("account");
		try{
		sblocca.setLoggedAccountUsername(loggedAccount.getUsername());
		sblocca.setLoggedAccountPassword(loggedAccount.getPassword());		
		}
		catch(NullPointerException np){
			throw new NoPermissionException();
		}
		WSSbloccaNotizieStub.SbloccaNotizieResponse res= stub.sbloccaNotizie(sblocca);
		res.get_return();
		//courtesy = "<spring:message code=\"messages.courtesy.success.sbloccanotizie\" /><br />";
		courtesy="messages.courtesy.success.sbloccanotizie";
		
	
	
	return new ModelAndView("courtesyPage", "message", courtesy);
}}

