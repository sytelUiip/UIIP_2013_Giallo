package it.gruppogiallo.ui.test;

import it.gruppogiallo.visualizzalistanotizie.WSVisualizzaNotizieStub;
import it.gruppogiallo.visualizzalistanotizie.WSVisualizzaNotizieStub.Notizia;

import java.awt.event.WindowStateListener;
import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

public class TestWSListaNotizie {

	public static void main(String[] args) {
		try {
			WSVisualizzaNotizieStub stub = new WSVisualizzaNotizieStub();
			WSVisualizzaNotizieStub.ListaNotizie notizie = new WSVisualizzaNotizieStub.ListaNotizie();
			notizie.setLoggedAccountPassword("114cniiuinkmjk72aa1p5807u3");
			notizie.setLoggedAccountUsername("admin");
			notizie.setMinLimit(0);
			notizie.setMaxLimit(1);
			WSVisualizzaNotizieStub.ListaNotizieResponse notizieResp = stub.listaNotizie(notizie);
			Notizia[] arrayNotizie = notizieResp.get_return();
			for(int i=0; i<arrayNotizie.length;i++ ) {
				System.out.println(arrayNotizie[i].getTitolo());
			}
		} catch (AxisFault e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
	}
}
