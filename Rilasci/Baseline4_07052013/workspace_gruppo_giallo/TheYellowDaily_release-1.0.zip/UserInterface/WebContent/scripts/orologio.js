var giorni1 = Array("domenica","luned�","marted�","mercoled�","gioved�","venerd�","sabato");
var giorni = Array("DOM","LUN","MAR","MER","GIO","VEN","SAB");
var mesi = Array("gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre");
	
function mytime() {
	var x = new Date();
	gg_label = giorni[x.getDay()];
	mm_label = mesi[x.getMonth()];
	gg = x.getDate();
	mm = x.getMonth()+1;
	aaaa = x.getFullYear();
	h = x.getHours();
	m = x.getMinutes();
	s = x.getSeconds();
	if(gg<=9) gg="0"+gg;
	if(mm<=9) mm="0"+mm;
	if(s<=9) s="0"+s;
	if(m<=9) m="0"+m;
	if(h<=9) h="0"+h;
	//time = gg_label + " " + gg + " " + mm_label + " " + aaaa + ", ore " + h + "." + m + "." + s;
	
	data = gg + "-" + mm+ "-" + aaaa; 
	ora =  " / " + h + "." + m + "." + s;
	
	mio_orologio = document.getElementById("orologio");
	//mio_orologio.innerHTML = time;
	mio_orologio.innerHTML = data + " " + ora;
	setTimeout("mytime()",1000);
}