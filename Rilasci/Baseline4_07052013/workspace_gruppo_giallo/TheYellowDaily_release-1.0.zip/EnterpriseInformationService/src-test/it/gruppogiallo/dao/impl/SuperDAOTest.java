package it.gruppogiallo.dao.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import it.gruppogiallo.entity.Account;
import it.gruppogiallo.entity.Funzionalita;
import it.gruppogiallo.entity.Gruppo;
import it.gruppogiallo.entity.Notizia;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runners.Parameterized.Parameters;

public class SuperDAOTest {
	
	SuperDAO dao = null;	
	Account account1 = null;	
	Notizia notizia1 = null;
	Notizia notizia2 = null;
	Notizia notizia3 = null;
	private static Map<String, Boolean> results = null;
	private static final Logger logger = Logger.getLogger(SuperDAOTest.class);

	@Parameters
	public Collection<Object[]> data() {
		Object[][] data = new Object[][] { { 100 }, { 200 }, { 300 }, { 400 },
				{ 500 } };
		return Arrays.asList(data);
	}
	
	@BeforeClass
	public static void inizialize() {
		results=  new HashMap<String, Boolean>();
		logger.debug("JUNIT - SuperDAO test STARTING");
	}

	@Before
	public void setUp() {
		dao = new SuperDAO();

		account1 = new Account("usernameTEST", "password", "NomeTEST",
				"CognomeTEST", "prova@abTEST.com", "SRTEST", "SGTEST", "A");

		notizia1 = new Notizia();
		notizia1.setStato("S");
		notizia1.setLockNotizia("N");
		notizia1.setTitolo("prova");
		notizia1.setSottotitolo("prova");
		notizia1.setTipologiaNotizia("prova");
		notizia1.setAutore(account1.getSiglaGiornalista());
		notizia1.setTesto("prova prova");
		notizia1.setLunghezzaTesto(23);

		notizia2 = new Notizia();
		notizia2.setStato("S");
		notizia2.setLockNotizia("N");
		notizia2.setTitolo("prova");
		notizia2.setSottotitolo("prova");
		notizia2.setTipologiaNotizia("prova");
		notizia2.setAutore("RCVTEST");
		notizia2.setTesto("prova prova");
		notizia2.setLunghezzaTesto(23);

		notizia3 = new Notizia();
		notizia3.setStato("S");
		notizia3.setLockNotizia("N");
		notizia3.setTitolo("prova");
		notizia3.setSottotitolo("prova");
		notizia3.setTipologiaNotizia("prova");
		notizia3.setAutore(account1.getSiglaGiornalista());
		notizia3.setTesto("prova prova");
		notizia3.setLunghezzaTesto(43);
	}
	
	/**
	 * Test method for
	 * {@link it.gruppogiallo.dao.impl.SuperDAO#getAccountFromUsername(java.lang.String)}
	 * .
	 */
	
	@Test
	public void testGetAccountFromUsername() {
		String username = "admin";
		Account acc = dao.getAccountFromUsername(username);
		Boolean result = acc.getUsername().equals(username);
		results.put("testGetAccountFromUsername",result);
		assertTrue(result);
	}

	/**
	 * Test method for
	 * {@link it.gruppogiallo.dao.impl.SuperDAO#createAccount(it.gruppogiallo.entity.Account)}
	 * .
	 */
	@Test
	public void testCreateAccount() {
		dao.createAccount(account1);
		Account account = dao.getAccountFromUsername(account1.getUsername());
		boolean found;
		if(account == null)	found = false;
		else				found = true;
		results.put("testCreateAccount",found);
		assertTrue(found);
	}

	@Test
	public void testGetSiglaGiornalista() {
		String SG=dao.getSiglaGiornalista(account1.getUsername());
		Boolean equals= (account1.getSiglaGiornalista().equals(SG));
		results.put("testGetSiglaGiornalista",equals);
		assertTrue(equals);
	}
	
	/**
	 * Test method for
	 * {@link it.gruppogiallo.dao.impl.SuperDAO#getAccountFromCredential(java.lang.String, java.lang.String)}
	 * .
	 */
	@Test
	public void testGetAccountFromCredential() {
		String username = "admin";
		String password = "114cniiuinkmjk72aa1p5807u3";
		Account acc = dao.getAccountFromCredential(username, password);
		Boolean isTrue = acc.getUsername().equals(username);
		results.put("testGetAccountFromCredential",isTrue);
		assertTrue(isTrue);
	}

	/**
	 * Test method for {@link it.gruppogiallo.dao.impl.SuperDAO#getAccounts()}.
	 */
	@Test
	public void testGetAccounts() {
		List<Account> acc = dao.getAccounts();
		Boolean isTrue =acc.size() > 0;
		results.put("testGetAccounts",isTrue);
		assertTrue(isTrue);
	}

	/**
	 * Test method for
	 * {@link it.gruppogiallo.dao.impl.SuperDAO#getLogin(java.lang.String, java.lang.String)}
	 * .
	 */
	@Test
	public void testGetLogin() {
		String username = "admin";
		String password = "admin";
		Account acc = dao.getLogin(username, password);
		Boolean isTrue = acc.getUsername().equals(username);
		results.put("testGetLogin",isTrue);
		assertTrue(isTrue);
	}

	/**
	 * Test method for
	 * {@link it.gruppogiallo.dao.impl.SuperDAO#isRegistered(java.lang.String)}.
	 */
	@Test
	public void testIsRegistered() {
		String username = "admin";
		boolean res = dao.isRegistered(username);
		results.put("testIsRegistered",res);
		assertTrue(res);
	}

	/**
	 * Test method for
	 * {@link it.gruppogiallo.dao.impl.SuperDAO#getGruppiByUsername(java.lang.String)}
	 * .
	 */
	@Test
	public void testGetGruppiByUsername() {
		String username = "admin";
		List<Gruppo> gruppi = dao.getGruppiByUsername(username);
		Boolean isTrue = gruppi.get(0).getNomeGruppo().equals("AMMINISTRATORE") && gruppi.get(1).getNomeGruppo().equals("GIORNALISTA");
		results.put("testGetGruppiByUsername",isTrue);
		assertTrue(isTrue);
	}

	@Test
	public void testInserimentoAppartenenzaGruppo() {
		List<Gruppo> gruppi = dao.getGruppiByUsername(account1.getUsername());
		Gruppo gruppoTest = new Gruppo("AMMINISTRATORE");
		boolean presente = false;
		boolean res = false;
		boolean isTrue=false;
		boolean cfr=false;
		for(Gruppo gr : gruppi){
			if(gr.getNomeGruppo().equals(gruppoTest.getNomeGruppo()))
				presente = true;
		}
		res = dao.inserimentoAppartenenzaGruppo(account1.getUsername(), gruppoTest.getNomeGruppo());
		if(!presente){
			isTrue=res;
			cfr=true;
		}
		res=(isTrue==cfr);
		results.put("testInserimentoAppartenenzaGruppo",res);
		assertTrue(res);
	}
	
	@Test
	public void testAggiungiAppartenenzaGruppo() {
		List<Gruppo> gruppi = dao.getGruppiByUsername(account1.getUsername());
		Gruppo g = new Gruppo("GIORNALISTA");
		boolean presente = false;
		boolean res = false;
		boolean isTrue=false;
		boolean cfr=false;
		for(Gruppo gr : gruppi){
			if(gr.getNomeGruppo().equals(g.getNomeGruppo()))
				presente = true;
		}
		res = dao.aggiungiAppartenenzaGruppo(account1.getUsername(), g.getNomeGruppo());
		if(!presente){
			isTrue=res;
			cfr=true;
			assertTrue(res == true);
		}
		res=(isTrue==cfr);
		results.put("testAggiungiAppartenenzaGruppo",res);
		assertTrue(res);
	}

	@Test
	public void testModificaAccount() {
		boolean res = dao.modificaAccount(account1.getUsername(), "pippo", account1.getCognome(), account1.getEmail(), account1.getSiglaRedazione(), account1.getSiglaGiornalista());
		boolean isTrue = res==true;
		results.put("testModificaAccount",isTrue);
		assertTrue(isTrue);
	}

	@Test
	public void testCancellaAppartenenzaGruppo() {
		boolean res = dao.cancellaAppartenenzaGruppo(account1.getUsername());
		boolean isTrue = res==true;
		results.put("testCancellaAppartenenzaGruppo",isTrue);
		assertTrue(isTrue);
	}

	@Test
	public void testAggiornaAppartenenzaGruppo() {
		List<Gruppo> gruppi = new ArrayList<Gruppo>();
		gruppi.add(new Gruppo("AMMINISTRATORE"));
		boolean res = dao.aggiornaAppartenenzaGruppo(account1.getUsername(), gruppi);
		boolean isTrue= res==true;
		results.put("testAggiornaAppartenenzaGruppo",isTrue);
		assertTrue(isTrue);
	}

	@Test
	public void testListaFunzionalitabyUsername() {
		List<Funzionalita> funzioni = dao.listaFunzionalitabyUsername(account1.getUsername());
		List<Gruppo> gruppi = dao.getGruppiByUsername(account1.getUsername());
		boolean res = false;
		
		for(Gruppo g : gruppi){
			if(g.getNomeGruppo().equals("AMMINISTRATORE")){
				for(Funzionalita f : funzioni){
					if(f.getNomeFunzionalita().equals("CreaAccount"))
						res = true;
				}
			}
			if(g.getNomeGruppo().equals("GIORNALISTA")){
				for(Funzionalita f : funzioni){
					if(f.getNomeFunzionalita().equals("CreazioneNotizia"))
						res = true;
				}
			}
		}
		results.put("testListaFunzionalitabyUsername",res);
		assertTrue(res);
	}
	
	@Test
	public void testCreateNotizia() {
		String username=account1.getUsername();	
		boolean res = dao.createNotizia(notizia1, username);
		boolean isTrue = res==true;
		results.put("testCreateNotizia",isTrue);
		assertTrue(isTrue);
	}

	@Test
	public void testCreateNotiziaEsterna() {
		boolean res = dao.createNotiziaEsterna(notizia2);
		boolean isTrue= res==true;
		results.put("testCreateNotizia",isTrue);
		assertTrue(res == true);
	}

	@Test
	public void testRicercaNotiziePerStato() {
		List<Notizia> notizie=new ArrayList<Notizia>();
		notizie=dao.ricercaNotiziePerStato(notizia1.getStato(), 1, 10);
		assertEquals(notizia1.getStato(), notizie.get(0).getStato());
	}

	@Test
	public void testRicercaNotiziePerStatoNOLIMIT() {
		List<Notizia> notizie=new ArrayList<Notizia>();
		notizie=dao.ricercaNotiziePerStatoNOLIMIT(notizia1.getStato());
		assertEquals(notizia1.getStato(), notizie.get(0).getStato());
	}
	
	@Test
	public void testListaNotizie() {
		List<Notizia> notizie=new ArrayList<Notizia>();
		notizie=dao.listaNotizie(1, 3);
		assertEquals(notizia1.getStato(), notizie.get(0).getStato());
	}
	
	@Test
	public void testRicercaNotiziePerAutore() {
		List<Notizia> notizie=new ArrayList<Notizia>();
		notizie=dao.ricercaNotiziePerAutore(notizia1.getAutore(), 1, 12);
		assertEquals(notizia1.getAutore(), notizie.get(0).getAutore());
	}
	
	@Test
	public void testRicercaNotiziePerTitolo() {
		List<Notizia> notizie=new ArrayList<Notizia>();
		notizie=dao.ricercaNotiziePerTitolo(notizia1.getTitolo(), 1, 11);
		assertEquals(notizia1.getTitolo(), notizie.get(0).getTitolo());
	}

	@Test
	public void testVisualizzaNotizia() {
		List<Notizia> notizia=new ArrayList<Notizia>();
		notizia=dao.ricercaNotiziePerTitolo(notizia1.getTitolo(),1,1);
		Notizia notiziaprova=new Notizia();		
		long id=notizia.get(0).getId();
		notiziaprova = dao.visualizzaNotizia(id);		
		assertEquals("prova", notiziaprova.getTitolo());
	}
	
	@Test
	public void testModificaNotizia() {
		String username=account1.getUsername();
		String ultimoDigitatore=dao.getSiglaGiornalista(username);
		List<Notizia> notizia=new ArrayList<Notizia>();
		notizia=dao.ricercaNotiziePerTitolo(notizia1.getTitolo(),1,1);
		long id=notizia.get(0).getId();
		dao.modificaNotizia(id, ultimoDigitatore);
		Notizia notiziaprova = dao.visualizzaNotizia(id);
		assertTrue(("Y".equals(notiziaprova.getLockNotizia()) && ("SGTEST".equals(notiziaprova.getUltimoDigitatore()))));	
	}
	
	@Test
	public void testRegistraNotizia() {	
		List<Notizia> notizia=new ArrayList<Notizia>();
		notizia=dao.ricercaNotiziePerTitolo(notizia1.getTitolo(),1,1);
		long id=notizia.get(0).getId();
		dao.registraNotizia(id, notizia3.getTitolo(), notizia3.getSottotitolo(), notizia3.getTipologiaNotizia(), notizia3.getTesto(), notizia3.getLunghezzaTesto());	
		Notizia notiziaprova = dao.visualizzaNotizia(id);
		
		assertTrue(("N".equals(notiziaprova.getLockNotizia()) && ("prova".equals(notiziaprova.getTitolo()))));	
	}
	
	@Test
	public void testChangeStatoNotizia() {
		List<Notizia> notizia=new ArrayList<Notizia>();
		notizia=dao.ricercaNotiziePerTitolo(notizia1.getTitolo(),1,1);
		long id=notizia.get(0).getId();
		dao.changeStatoNotizia(id, "Q");
		Notizia notiziaprova = dao.visualizzaNotizia(id);
		assertTrue("Q".equals(notiziaprova.getStato()));
	}
	
	@Test
	public void testAnnullaModifica() {
		List<Notizia> notizia=new ArrayList<Notizia>();
		notizia=dao.ricercaNotiziePerTitolo(notizia1.getTitolo(),1,1);
		long id=notizia.get(0).getId();
		dao.annullaModifica(id);
		Notizia notiziaprova=new Notizia();
		notiziaprova=dao.visualizzaNotizia(id);
		assertTrue(("N".equals(notiziaprova.getLockNotizia())));
	}
	
	@Test
	public void testSbloccaNotizieByUsername() {
		List<Notizia> notizia = dao.ricercaNotiziePerTitolo(notizia1.getTitolo(),1,1);
		long id=notizia.get(0).getId();
		String username=account1.getUsername();
		String SG=dao.getSiglaGiornalista(username);
		dao.modificaNotizia(id, SG);			
		dao.sbloccaNotizieByUsername(username);
		Notizia notiziaprova = dao.visualizzaNotizia(id);
		assertTrue(("N".equals(notiziaprova.getLockNotizia())));
	}
	
	@Test
	public void testTrasmettiNotizia() {
		List<Notizia> notizia=new ArrayList<Notizia>();
		notizia=dao.ricercaNotiziePerTitolo(notizia1.getTitolo(),1,1);
		long id=notizia.get(0).getId();
		dao.trasmettiNotizia(id);
		Notizia notiziaprova=new Notizia();
		notiziaprova=dao.visualizzaNotizia(id);			
		assertEquals("Q", notiziaprova.getStato());
	}
	
	@Test
	public void testCancellaNotizia() {	
		List<Notizia> notizia=new ArrayList<Notizia>();
		notizia=dao.ricercaNotiziePerTitolo(notizia1.getTitolo(),1,1);
		long id=notizia.get(0).getId();
		dao.cancellaNotizia(id);
		Notizia notiziaprova=new Notizia();
		notiziaprova=dao.visualizzaNotizia(id);
		assertEquals("C", notiziaprova.getStato());		
	}
	
	@Test
	public void testCancellaAccount() {
		dao.cancellaAccount(account1.getUsername());
		Account account = dao.getAccountFromUsername(account1.getUsername());
		assertEquals("D", account.getStato());
	}
	
	@Test
	public void testGestioneCancellaNotizia() {
		boolean res=dao.gestioneCancellaNotizia(account1.getUsername());
		assertTrue(res);
	}
	
	@Test
	public void testSbloccaNotizia() {
		List<Long> id = dao.getIdNotiziaBloccataByUltimoDig(account1.getSiglaGiornalista());		
		boolean res=dao.sbloccaNotizia(id);
		assertTrue(res==true);
		
	}

	@Test
	public void testCancellazioneEffettivaNotiziaEsterna() {
		dao.cancellazioneEffettivaNotiziaEsterna(notizia2.getAutore());
		List<Notizia> notizie = dao.ricercaNotiziePerAutore(notizia2.getAutore(), 1, 10);
		assertTrue(notizie.size() == 0);
	}
	
	@Test
	public void testCancellazioneEffettivaNotizia() {
		dao.cancellazioneEffettivaNotizia(account1.getUsername());
		List<Notizia> notizie = dao.ricercaNotiziePerAutore(notizia1.getAutore(), 1, 10);
		assertTrue(notizie.size() == 0);
	}
	
	@Test
	public void testCancellazioneEffettivaAccount() {
		dao.cancellazioneEffettivaAccount(account1.getUsername());
		Account account = dao.getAccountFromUsername(account1.getUsername());
		assertTrue(account == null);
	}
	
	@AfterClass
	public static void finalization() {
		for( Entry<String, Boolean> iter :results.entrySet()) {
			logger.debug("Method: "+iter.getKey()+" has result "+iter.getValue());
		}
		logger.debug("JUNIT - SuperDAO testing complete");
	}
}
