package it.gruppogiallo.trasmitter.test;


import it.gruppogiallo.trasmitter.Trasmitter;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class MainTrasmitter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scheduler scheduler;
        try {
            scheduler = StdSchedulerFactory.getDefaultScheduler();

            scheduler.start();
            
            JobDetail job = JobBuilder.newJob(Trasmitter.class)
            .withIdentity("job1", "group1")
            .build();
            
            Trigger trigger = TriggerBuilder.newTrigger()
            .withIdentity("trigger1", "group1")
            .startNow()
            .withSchedule(SimpleScheduleBuilder.simpleSchedule()
            .withIntervalInSeconds(5)
            .repeatForever())
            .build();
            
            scheduler.scheduleJob(job, trigger);
            

        } catch (SchedulerException e) {
        	System.out.println(e.getMessage());
		} 
    }

}
