package it.gruppogiallo.trasmitter;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Notizia;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class Trasmitter implements Job {

	private static final Logger logger = Logger.getLogger(Trasmitter.class);
	private static Document document;
	
	
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		SuperDAO dao = new SuperDAO();
		List<Notizia> listaNotizie = dao.ricercaNotiziePerStatoNOLIMIT("Q");
		
		for(Notizia notizia : listaNotizie){
			createDocument();
			createNotizia(notizia);
			transformToXml(notizia);
			dao.changeStatoNotizia(notizia.getId(), "T");
		}
		
	}
	
	private void transformToXml(Notizia news){
		String folder = "C:/theyellowdaily/news";
		String subFolder = "C:/theyellowdaily/news/outcoming";
		new File(folder).mkdir();
		new File(subFolder).mkdir();
		
		//create Data transmission
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		DateFormat dateFormatForFile = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		news.setDataTrasmissione(convertToDate(dateFormat.format(cal.getTime())));
		try {
		TransformerFactory transformerFactory = TransformerFactory
				.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty(
				"{http://xml.apache.org/xslt}indent-amount", "4");
		DOMSource source = new DOMSource(document);
		File output = new File(subFolder+"/"+news.getDataCreazione()+"-"+news.getId()+"-"+dateFormatForFile.format(cal.getTime())+".xml");
		StreamResult result = new StreamResult(output);
		transformer.transform(source, result);
		
		} catch (TransformerException e) {
			e.printStackTrace();
		}

		logger.debug("TRASMITTER: News ID "+news.getId()+" sent.");
	}
	
	private void createNotizia(Notizia news) {
		
		Element notizia = document.createElement("Notizia");
		document.appendChild(notizia);

		Element anagrafica = document.createElement("Anagrafica");
		anagrafica.setAttribute("Titolo", news.getTitolo());
		anagrafica.setAttribute("Sottotitolo", news.getSottotitolo());
		anagrafica.setAttribute("Autore", news.getAutore());
		anagrafica.setAttribute("UltimoDigitatore", news.getUltimoDigitatore());
		anagrafica.setAttribute("DataCreazione", news.getDataCreazione().toString());
		
		Element testo = document.createElement("Testo");
		testo.setTextContent(news.getTesto());
		
		notizia.appendChild(anagrafica);
		notizia.appendChild(testo);
	}
	
	private void createDocument(){
		DocumentBuilderFactory documentFactory = DocumentBuilderFactory
				.newInstance();
		documentFactory.setValidating(true);

		DocumentBuilder documentBuilder;

		try {
			documentBuilder = documentFactory.newDocumentBuilder();
			document = documentBuilder.newDocument();
		} catch (ParserConfigurationException pce) {
		}
	}

	private Date convertToDate(String stringa) {
		DateFormat formatter = null;
		Date myConvertedDate = null;

		// conversione String a Date conversion
		formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		try {
			myConvertedDate = (Date) formatter.parse(stringa);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return myConvertedDate;
	}
	
}
