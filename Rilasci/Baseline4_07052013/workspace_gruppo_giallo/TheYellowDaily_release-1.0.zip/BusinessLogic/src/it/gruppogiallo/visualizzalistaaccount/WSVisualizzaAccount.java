package it.gruppogiallo.visualizzalistaaccount;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Account;
import it.gruppogiallo.security.Security;

import java.util.List;

import org.apache.log4j.Logger;

public class WSVisualizzaAccount {

	private SuperDAO dao;
	private static final Logger logger = Logger
			.getLogger(WSVisualizzaAccount.class);

	public List<Account> visualizzaAccount(String loggedAccountUsername,
			String loggedAccountPassword) {
		logger.debug("WEBSERVICE: WSVisualizzaAccount - Service "
				+ " visualizzaAccount called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "ListaAccount")) {
			dao = new SuperDAO();
			return dao.getAccounts();
		}
		return null;
	}
}
