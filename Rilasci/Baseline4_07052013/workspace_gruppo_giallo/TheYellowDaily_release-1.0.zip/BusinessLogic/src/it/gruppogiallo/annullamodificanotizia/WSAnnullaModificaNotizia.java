package it.gruppogiallo.annullamodificanotizia;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.security.Security;

import org.apache.log4j.Logger;

public class WSAnnullaModificaNotizia {

	private SuperDAO dao = new SuperDAO();
	private static final Logger logger = Logger
			.getLogger(WSAnnullaModificaNotizia.class);

	public boolean annullaModificaNotizia(String loggedAccountUsername,
			String loggedAccountPassword, long id) {
		boolean result = true;
		logger.debug("WEBSERVICE: WSAnnullaModificaNotizia - Service "
				+ " annullaModificaNotizia called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "Annulla")) {
			dao.annullaModifica(id);
			result = true;
		}
		return result;

	}

}
