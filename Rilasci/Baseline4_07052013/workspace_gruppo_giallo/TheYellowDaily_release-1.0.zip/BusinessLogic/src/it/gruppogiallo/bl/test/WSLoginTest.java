package it.gruppogiallo.bl.test;

import it.gruppogiallo.login.WSLogin;

public class WSLoginTest {

	public static void main(String[] args) {
		WSLogin testLogin = new WSLogin();
		testLogin.getLogin("admin", "admin");
	}
}
