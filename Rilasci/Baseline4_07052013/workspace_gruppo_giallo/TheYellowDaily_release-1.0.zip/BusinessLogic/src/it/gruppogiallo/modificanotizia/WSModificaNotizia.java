package it.gruppogiallo.modificanotizia;

import org.apache.log4j.Logger;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Notizia;
import it.gruppogiallo.security.Security;

public class WSModificaNotizia {

	private static final Logger logger = Logger
			.getLogger(WSModificaNotizia.class);
	SuperDAO dao = new SuperDAO();

	public Notizia modificaNotizia(String loggedAccountUsername,
			String loggedAccountPassword, long id) {

		logger.debug("WEBSERVICE: WSModificaNotizia - Service "
				+ " modificaNotizia called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "ModificaNotizia")) {
			String siglaGiornalista = dao
					.getSiglaGiornalista(loggedAccountUsername);
			dao.modificaNotizia(id, siglaGiornalista);
		}
		return dao.visualizzaNotizia(id);
	}
}
