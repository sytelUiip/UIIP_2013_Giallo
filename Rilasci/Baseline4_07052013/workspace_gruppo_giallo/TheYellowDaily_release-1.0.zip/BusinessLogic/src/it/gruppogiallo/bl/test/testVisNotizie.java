package it.gruppogiallo.bl.test;

import it.gruppogiallo.entity.Notizia;
import it.gruppogiallo.visualizzalistanotizie.WSVisualizzaNotizie;

import java.util.ArrayList;
import java.util.List;

public class testVisNotizie {

	public static void main(String[] args) {

		WSVisualizzaNotizie visualizzaNotizie = new WSVisualizzaNotizie();
		List<Notizia> listaNotizie = new ArrayList<Notizia>();
		
		listaNotizie=visualizzaNotizie.ricercaNotiziePerTitolo("admin", "114cniiuinkmjk72aa1p5807u3","Titolo", 0, 3);
		for(Notizia n: listaNotizie) {
			System.out.println(n);
		}
	}
}
