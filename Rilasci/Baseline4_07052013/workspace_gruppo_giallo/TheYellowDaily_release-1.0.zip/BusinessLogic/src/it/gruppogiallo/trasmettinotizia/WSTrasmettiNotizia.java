package it.gruppogiallo.trasmettinotizia;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.security.Security;

import org.apache.log4j.Logger;

public class WSTrasmettiNotizia {
	private static final Logger logger = Logger
			.getLogger(WSTrasmettiNotizia.class);
	SuperDAO dao = new SuperDAO();
	boolean result = false;

	public boolean trasmettiNotizia(String loggedAccountUsername,
			String loggedAccountPassword, long id) {
		logger.debug("WEBSERVICE: WSTrasmettiNotizia - Service "
				+ " trasmettiNotizia called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "TrasmettiNotizia")) {
			result = dao.trasmettiNotizia(id);

		}
		return result;
	}
}
