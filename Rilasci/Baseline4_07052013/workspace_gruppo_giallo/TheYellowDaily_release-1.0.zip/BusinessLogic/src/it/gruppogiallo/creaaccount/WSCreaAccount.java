package it.gruppogiallo.creaaccount;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Account;
import it.gruppogiallo.security.Security;

import org.apache.log4j.Logger;

public class WSCreaAccount {

	private SuperDAO dao;
	private static final Logger logger = Logger.getLogger(WSCreaAccount.class);

	public boolean crea(String loggedAccountUsername,
			String loggedAccountPassword, String nome, String cognome,
			String username, String password, String email,
			String siglaRedazione, String siglaGiornalista) {
		logger.debug("WEBSERVICE: WSCreaAccount - Service "
				+ " crea called in BL");
		boolean result = false;
		Security security = new Security();

		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "CreaAccount")) {
			dao = new SuperDAO();
			Account account = new Account(username, password, nome, cognome,
					email, siglaRedazione, siglaGiornalista, "A");
			System.out.println(account.toString());
			result = dao.createAccount(account);
		}
		return result;
	}
}
