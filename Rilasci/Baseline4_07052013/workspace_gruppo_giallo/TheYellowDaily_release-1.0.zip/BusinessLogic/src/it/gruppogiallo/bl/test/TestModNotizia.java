package it.gruppogiallo.bl.test;

import it.gruppogiallo.entity.Notizia;
import it.gruppogiallo.modificanotizia.WSModificaNotizia;

public class TestModNotizia {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WSModificaNotizia modifica = new WSModificaNotizia();
		Notizia notizia = modifica.modificaNotizia("admin", "114cniiuinkmjk72aa1p5807u3", 5);
//		notizia = modifica.modificaNotizia("admin", "114cniiuinkmjk72aa1p5807u3", 7);
//		notizia = modifica.modificaNotizia("admin", "114cniiuinkmjk72aa1p5807u3", 21);		
	}

}
