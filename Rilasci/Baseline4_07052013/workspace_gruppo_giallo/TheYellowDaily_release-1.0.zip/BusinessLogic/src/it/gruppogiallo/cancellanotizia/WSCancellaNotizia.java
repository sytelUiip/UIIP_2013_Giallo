package it.gruppogiallo.cancellanotizia;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.security.Security;

import org.apache.log4j.Logger;

public class WSCancellaNotizia {

	private SuperDAO dao;
	private static final Logger logger = Logger
			.getLogger(WSCancellaNotizia.class);

	public boolean cancellaNotizia(String loggedAccountUsername,
			String loggedAccountPassword, long id) {
		boolean result = false;
		dao = new SuperDAO();
		logger.debug("WEBSERVICE: WSCancellaNotizia - Service "
				+ " cancellaNotizia called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "CancellazioneNotizia")) {
			dao.cancellaNotizia(id);
			result = true;
		}
		return result;
	}
}