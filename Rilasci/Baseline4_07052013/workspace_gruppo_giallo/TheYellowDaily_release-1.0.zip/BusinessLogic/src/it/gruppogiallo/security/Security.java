package it.gruppogiallo.security;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Account;
import it.gruppogiallo.entity.Funzionalita;

import java.util.List;

import org.apache.log4j.Logger;

public class Security {

	private static final Logger logger = Logger.getLogger(Security.class);

	public boolean getPermission(String username, String password,
			String funzionalita) {
		logger.debug("Web Service Security called for Account: " + username);
		SuperDAO dao = new SuperDAO();
		boolean isAllowed = false;
		Account account = dao.getAccountFromCredential(username, password);
		if (account != null) {
			List<Funzionalita> listaFunzionalita = dao
					.listaFunzionalitabyUsername(username);
			for (Funzionalita f : listaFunzionalita) {
				if (f.getNomeFunzionalita().equalsIgnoreCase(funzionalita)) {
					isAllowed = true;
				}
			}
			if (isAllowed) {
				logger.debug("Account: " + username
						+ " is allowed to execute the operation: "
						+ funzionalita);
				return true;
			} else {
				logger.debug("Account: " + username
						+ " is not allowed to execute the operation: "
						+ funzionalita);
				return false;
			}
		} else {
			logger.warn("Account: " + username + " is not registered");
		}
		return false;
	}
}
