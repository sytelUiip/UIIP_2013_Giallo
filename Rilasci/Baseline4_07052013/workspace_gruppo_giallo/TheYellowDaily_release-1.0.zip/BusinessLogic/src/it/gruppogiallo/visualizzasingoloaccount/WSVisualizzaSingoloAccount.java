package it.gruppogiallo.visualizzasingoloaccount;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Account;
import it.gruppogiallo.security.Security;

import org.apache.log4j.Logger;

public class WSVisualizzaSingoloAccount {
	private SuperDAO dao;
	private static final Logger logger = Logger
			.getLogger(WSVisualizzaSingoloAccount.class);

	public Account visualizza(String loggedAccountUsername,
			String loggedAccountPassword, String username) {
		logger.debug("WEBSERVICE: WSVisualizzaSingoloAccount - Service "
				+ " visualizza called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "ListaAccount")) {
			dao = new SuperDAO();
			return dao.getAccountFromUsername(username);
		}
		return null;
	}
}
