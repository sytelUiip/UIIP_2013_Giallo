package it.gruppogiallo.sbloccanotizie;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.security.Security;

import org.apache.log4j.Logger;

public class WSSbloccaNotizie {

	private SuperDAO dao;
	private static final Logger logger = Logger
			.getLogger(WSSbloccaNotizie.class);

	public boolean sbloccaNotizie(String loggedAccountUsername,
			String loggedAccountPassword) {
		boolean result = false;
		dao = new SuperDAO();
		logger.debug("WEBSERVICE: WSSbloccaNotizie - Service "
				+ " sbloccaNotizie called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "sbloccaNotizie")) {
			dao.sbloccaNotizieByUsername(loggedAccountUsername);
			result = true;
		}
		return result;
	}
}
