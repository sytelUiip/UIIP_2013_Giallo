package it.gruppogiallo.visualizzalistanotizie;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Notizia;
import it.gruppogiallo.security.Security;

public class WSVisualizzaNotizie {

	private SuperDAO dao;
	private static final Logger logger = Logger
			.getLogger(WSVisualizzaNotizie.class);

	public List<Notizia> listaNotizie(String loggedAccountUsername,
			String loggedAccountPassword, int minLimit, int maxLimit) {
		// Minimum limit value under 1 is not accepted
		if (minLimit < 1)
			minLimit = 1;
		// If the maximum limit value is less than the minimun value
		// it will be equal to it
		if (maxLimit < minLimit)
			maxLimit = minLimit;
		// Null to prevent malware access from extern
		List<Notizia> notizie = null;
		logger.debug("WEBSERVICE: WSVisualizzaNotizie - Service "
				+ " visualizzaNotizie called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "ListaNotizia")) {
			dao = new SuperDAO();
			notizie = dao.listaNotizie(minLimit, maxLimit);
		}
		return notizie;
	}

	public List<Notizia> ricercaNotiziePerStato(String loggedAccountUsername,
			String loggedAccountPassword, String stato, int minLimit,
			int maxLimit) {

		List<Notizia> notizie = new ArrayList<Notizia>();
		logger.debug("WEBSERVICE: WSVisualizzaNotizie - Service "
				+ " ricercaNotiziePerStato called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "listaNotizia")) {
			dao = new SuperDAO();
			notizie = dao.ricercaNotiziePerStato(stato, minLimit, maxLimit);
		}
		return notizie;
	}

	public List<Notizia> ricercaNotiziePerAutore(String loggedAccountUsername,
			String loggedAccountPassword, String autore, int minLimit,
			int maxLimit) {

		List<Notizia> notizie = new ArrayList<Notizia>();

		logger.debug("WEBSERVICE: WSVisualizzaNotizie - Service "
				+ " ricercaNotiziePerAutore called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "listaNotizia")) {
			dao = new SuperDAO();
			notizie = dao.ricercaNotiziePerAutore(autore, minLimit, maxLimit);
		}
		return notizie;
	}

	public List<Notizia> ricercaNotiziePerTitolo(String loggedAccountUsername,
			String loggedAccountPassword, String titolo, int minLimit,
			int maxLimit) {

		List<Notizia> notizie = new ArrayList<Notizia>();

		logger.debug("WEBSERVICE: WSVisualizzaNotizie - Service "
				+ " ricercaNotiziePerTitolo called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "listaNotizia")) {
			dao = new SuperDAO();
			notizie = dao.ricercaNotiziePerTitolo(titolo, minLimit, maxLimit);
		}
		return notizie;
	}

}
