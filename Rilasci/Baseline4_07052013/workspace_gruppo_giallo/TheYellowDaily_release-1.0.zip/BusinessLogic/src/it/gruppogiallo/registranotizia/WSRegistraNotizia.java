package it.gruppogiallo.registranotizia;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.security.Security;

import org.apache.log4j.Logger;

public class WSRegistraNotizia {

	private SuperDAO dao = new SuperDAO();
	private static final Logger logger = Logger
			.getLogger(WSRegistraNotizia.class);

	public boolean registraNotizia(String loggedAccountUsername,
			String loggedAccountPassword, long id, String titolo,
			String sottotitolo, String tipologiaNotizia, String testo) {
		logger.debug("WEBSERVICE: WSRegistraNotizia - Service "
				+ " registraNotizia called in BL");
		boolean result = false;
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "RegistraNotizia")) {
			int lunghezzaTesto = testo.length();
			result = dao.registraNotizia(id, titolo, sottotitolo,
					tipologiaNotizia, testo, lunghezzaTesto);
		}
		return result;
	}
}
