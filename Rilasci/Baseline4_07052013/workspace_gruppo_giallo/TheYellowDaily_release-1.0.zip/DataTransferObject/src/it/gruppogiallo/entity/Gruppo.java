package it.gruppogiallo.entity;

/*import org.apache.log4j.Logger;*/

public class Gruppo extends DTO {

	private static final long serialVersionUID = 1L;
	private String nomeGruppo;
	private Account[] accounts;

	/* private static final Logger logger = Logger.getLogger(Gruppo.class); */

	public Gruppo(String nomeGruppo) {
		super();
		this.nomeGruppo = nomeGruppo;
		/*
		 * logger.debug("Class: Gruppo - "+" constructor called in DTO");
		 * logger.debug("Gruppo parameters: "+" nomeGruppo("+nomeGruppo+")");
		 */
	}

	public String getNomeGruppo() {
		return nomeGruppo;
	}

	public void setNomeGruppo(String nomeGruppo) {
		this.nomeGruppo = nomeGruppo;
	}

	public Account[] getAccounts() {
		return accounts;
	}

	public void setAccounts(Account[] accounts) {
		this.accounts = accounts;
	}

	@Override
	public String toString() {
		return this.nomeGruppo + "\t";
	}
}