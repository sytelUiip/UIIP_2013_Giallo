package it.gruppogiallo.exception;

import java.io.PrintStream;
import java.io.PrintWriter;

import org.apache.log4j.Logger;

public class NoPermissionException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger
			.getLogger(NoPermissionException.class);
	
	public NoPermissionException(){
		logger.warn("NoPermissionException: you have no permission to access this function");
	}
	
	public String getMessage() {
		return "600";
	}
	
	@Override
	public void printStackTrace(PrintStream s) {

	}

	@Override
	public void printStackTrace(PrintWriter s) {

	}
}
