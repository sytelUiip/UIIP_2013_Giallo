DELETE FROM editoria_gruppo_giallo.NOTIZIA;
DELETE FROM editoria_gruppo_giallo.FUNZIONALITA;
DELETE FROM editoria_gruppo_giallo.APPARTENENZA_GRUPPO;
DELETE FROM editoria_gruppo_giallo.GRUPPO;
DELETE FROM editoria_gruppo_giallo.ACCOUNT;