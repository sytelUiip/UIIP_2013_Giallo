create user editoria_gruppo_giallo identified by giallo;
grant all privileges to editoria_gruppo_giallo;
disconnect;
connect editoria_gruppo_giallo;