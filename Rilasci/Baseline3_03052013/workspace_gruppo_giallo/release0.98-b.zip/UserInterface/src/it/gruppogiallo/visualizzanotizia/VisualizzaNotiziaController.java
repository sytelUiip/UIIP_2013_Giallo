package it.gruppogiallo.visualizzanotizia;

import java.rmi.RemoteException;
import java.util.Properties;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.visualizzanotizia.WSVisualizzaNotiziaStub.Notizia;
import it.gruppogiallo.wsmanager.WSManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class VisualizzaNotiziaController extends AbstractController {

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Properties wsManager = WSManager.getWSProperties();

		String serviceName = "WSVisualizzaNotizia";
		String wsEndpoint = "http://";
		wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
		wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
		wsEndpoint += wsManager.getProperty(serviceName + "-Base");
		wsEndpoint += "/services/" + serviceName + "." + serviceName
				+ "HttpSoap12Endpoint/";

		logger.debug("Class VisualizzaNotiziaController - handleRequestInternal called in UI");
		WSVisualizzaNotiziaStub stub = new WSVisualizzaNotiziaStub(null,wsEndpoint);
		WSVisualizzaNotiziaStub.VisualizzaNotizia visualizza = new WSVisualizzaNotiziaStub.VisualizzaNotizia();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request
				.getSession().getAttribute("account");
		visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
		visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
		visualizza.setId(Long.parseLong(request.getParameter("id")));
		WSVisualizzaNotiziaStub.VisualizzaNotiziaResponse res = null;
		try {
			res = stub.visualizzaNotizia(visualizza);
		} catch (RemoteException e) {
			if (e.getMessage().equals("100")) {
				throw new NoDBConnectionException();
			} else {
				throw new NoWSConnectionException(stub.getClass());
			}
		}

		Notizia notizia = res.get_return();

		return new ModelAndView("viewNotizia", "notizia", notizia);

	}

}
