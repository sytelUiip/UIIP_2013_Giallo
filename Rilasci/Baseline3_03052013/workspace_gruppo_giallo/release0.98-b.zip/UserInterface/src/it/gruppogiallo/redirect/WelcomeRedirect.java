package it.gruppogiallo.redirect;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class WelcomeRedirect extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(WelcomeRedirect.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String parameter = "";
		logger.debug("REDIRECT WelcomeRedirect - handleRequestInternal called in UI");
		if (request.getSession().getAttribute("isAdmin").equals("true")
				|| request.getSession().getAttribute("isAdmin").equals("both")) {
			parameter = "admin";
		} else {
			parameter = "journalist";
		}

		return new ModelAndView("home", "parameter", parameter);
	}

}
