package it.gruppogiallo.creazionenotizia;

import java.rmi.RemoteException;
import java.util.Properties;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.login.WSLoginStub.Account;
import it.gruppogiallo.wsmanager.WSManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class CreaNotiziaController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(CreaNotiziaController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		logger.debug("Class CreaNotiziaController - handleRequestInternal called in UI");
		String courtesyMessage = "";

		String titolo = request.getParameter("titolo");
		String sottotitolo = request.getParameter("sottotitolo");
		String tipologiaNotizia = request.getParameter("tipologia");
		String testo = request.getParameter("testo");

		if (titolo.equals("") || sottotitolo.equals("")
				|| tipologiaNotizia.equals("") || testo.equals(""))
			courtesyMessage = "messages.courtesy.fail.field.creanotizia";
		else {
			Properties wsManager = WSManager.getWSProperties();

			String serviceName = "WSCreaNotizia";
			String wsEndpoint = "http://";
			wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
			wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
			wsEndpoint += wsManager.getProperty(serviceName + "-Base");
			wsEndpoint += "/services/" + serviceName + "." + serviceName
					+ "HttpSoap12Endpoint/";

			WSCreaNotiziaStub stub = new WSCreaNotiziaStub(null, wsEndpoint);
			WSCreaNotiziaStub.CreaNotizia creaNotizia = new WSCreaNotiziaStub.CreaNotizia();
			Account loggedAccount = (Account) request.getSession()
					.getAttribute("account");
			creaNotizia.setLoggedAccountUsername(loggedAccount.getUsername());
			creaNotizia.setLoggedAccountPassword(loggedAccount.getPassword());
			creaNotizia.setTitolo(request.getParameter("titolo"));
			creaNotizia.setSottotitolo(request.getParameter("sottotitolo"));
			creaNotizia.setTipologiaNotizia(request.getParameter("tipologia"));
			creaNotizia.setTesto(request.getParameter("testo"));
			WSCreaNotiziaStub.CreaNotiziaResponse res = null;
			try {
				res = stub.creaNotizia(creaNotizia);
			} catch (RemoteException e) {
				if (e.getMessage().equals("100")) {
					throw new NoDBConnectionException();
				} else {
					throw new NoWSConnectionException(stub.getClass());
				}
			}
			Boolean bol = res.get_return();

			if (bol)
				courtesyMessage = "messages.courtesy.success.creanotizia";
			else
				courtesyMessage = "messages.courtesy.fail.creanotizia";

		}
		return new ModelAndView("courtesyPage", "message", courtesyMessage);
	}

}
