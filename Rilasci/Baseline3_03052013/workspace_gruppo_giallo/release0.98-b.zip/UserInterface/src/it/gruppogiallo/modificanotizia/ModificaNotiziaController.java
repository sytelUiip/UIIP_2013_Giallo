package it.gruppogiallo.modificanotizia;

import java.rmi.RemoteException;
import java.util.Properties;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.visualizzanotizia.WSVisualizzaNotiziaStub;
import it.gruppogiallo.visualizzanotizia.WSVisualizzaNotiziaStub.Notizia;
import it.gruppogiallo.wsmanager.WSManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class ModificaNotiziaController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(ModificaNotiziaController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String page="";
		String paramName="";
		Object param=null;
		
		logger.debug("Class ModificaNotiziaController - handleRequestInternal called in UI");
		Properties wsManager = WSManager.getWSProperties();
		String serviceName = "WSVisualizzaNotizia";
		String wsEndpoint = "http://";
		wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
		wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
		wsEndpoint += wsManager.getProperty(serviceName + "-Base");
		wsEndpoint += "/services/" + serviceName + "." + serviceName
				+ "HttpSoap12Endpoint/";
		
		WSVisualizzaNotiziaStub stubVisNotizia = new WSVisualizzaNotiziaStub(null, wsEndpoint);
		WSVisualizzaNotiziaStub.VisualizzaNotizia visualizza = new WSVisualizzaNotiziaStub.VisualizzaNotizia();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request
				.getSession().getAttribute("account");

		visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
		visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
		visualizza.setId(Long.parseLong(request.getParameter("id")));

		WSVisualizzaNotiziaStub.VisualizzaNotiziaResponse resVisualizza = stubVisNotizia
				.visualizzaNotizia(visualizza);
		Notizia notizia = new Notizia();
		notizia = resVisualizza.get_return();
		it.gruppogiallo.modificanotizia.WSModificaNotiziaStub.Notizia notizia2 = new it.gruppogiallo.modificanotizia.WSModificaNotiziaStub.Notizia();
		if (!(notizia.getStato().equals("S"))) {
			page="courtesyPage";
			paramName="message";
			param = "messages.courtesy.fail.modificanotizia";
		}
		else {
			if (
					(notizia.getLockNotizia().equals("Y")) && 
					(!(loggedAccount.getSiglaGiornalista().equals(notizia.getUltimoDigitatore())))
				) {
				page="courtesyPage";
				paramName="message";
				param="messages.courtesy.fail.noaccess.modificanotizia";

			} else {
				serviceName = "WSModificaNotizia";
				wsEndpoint = "http://";
				wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
				wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
				wsEndpoint += wsManager.getProperty(serviceName + "-Base");
				wsEndpoint += "/services/" + serviceName + "." + serviceName
						+ "HttpSoap12Endpoint/";
				WSModificaNotiziaStub stubModifica = new WSModificaNotiziaStub(null,wsEndpoint);
				WSModificaNotiziaStub.ModificaNotizia modifica = new WSModificaNotiziaStub.ModificaNotizia();

				modifica.setLoggedAccountUsername(loggedAccount.getUsername());
				modifica.setLoggedAccountPassword(loggedAccount.getPassword());

				modifica.setId(Long.parseLong(request.getParameter("id")));

				WSModificaNotiziaStub.ModificaNotiziaResponse resModifica = null;
				try {
					resModifica = stubModifica.modificaNotizia(modifica);
				} catch (RemoteException e) {
					if (e.getMessage().equals("100")) {
						throw new NoDBConnectionException();
					} else {
						throw new NoWSConnectionException(
								stubModifica.getClass());
					}
				}
				notizia2 = resModifica.get_return();
				page="modNotizia";
				paramName="notiziaDaModificare";
				param = notizia2;
			}

		}
		return new ModelAndView(page, paramName, param );

	}

}
