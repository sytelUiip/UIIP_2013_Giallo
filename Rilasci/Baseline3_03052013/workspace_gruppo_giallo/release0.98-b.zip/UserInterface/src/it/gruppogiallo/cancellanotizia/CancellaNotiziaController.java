package it.gruppogiallo.cancellanotizia;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.Properties;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.visualizzanotizia.WSVisualizzaNotiziaStub;
import it.gruppogiallo.visualizzanotizia.WSVisualizzaNotiziaStub.Notizia;
import it.gruppogiallo.wsmanager.WSManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class CancellaNotiziaController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(CancellaNotiziaController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String courtesy;
		logger.debug("Class CancellaNotiziaController - handleRequestInternal called in UI");

		Properties wsManager = WSManager.getWSProperties();

		String serviceName = "WSCancellaNotizia";
		String wsEndpoint = "http://";
		wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
		wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
		wsEndpoint += wsManager.getProperty(serviceName + "-Base");
		wsEndpoint += "/services/" + serviceName + "." + serviceName
				+ "HttpSoap12Endpoint/";

		WSVisualizzaNotiziaStub stubVisNotizia = new WSVisualizzaNotiziaStub();
		WSVisualizzaNotiziaStub.VisualizzaNotizia visualizza = new WSVisualizzaNotiziaStub.VisualizzaNotizia();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request
				.getSession().getAttribute("account");

		visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
		visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
		visualizza.setId(Long.parseLong(request.getParameter("id")));

		WSVisualizzaNotiziaStub.VisualizzaNotiziaResponse resVisualizza = stubVisNotizia
				.visualizzaNotizia(visualizza);
		Notizia notizia = new Notizia();
		notizia = resVisualizza.get_return();

		if (!(notizia.getStato().equals("S")))
			courtesy = "messages.courtesy.fail.cancellanotizia";
		else {
			if ((notizia.getLockNotizia().equals("Y"))
					&& (!(loggedAccount.getSiglaGiornalista().equals(notizia
							.getUltimoDigitatore())))) {
				courtesy = "messages.courtesy.fail.blocked.cancellanotizia";

			} else {
				WSCancellaNotiziaStub stubCancella = new WSCancellaNotiziaStub();
				WSCancellaNotiziaStub.CancellaNotizia cancella = new WSCancellaNotiziaStub.CancellaNotizia();

				cancella.setLoggedAccountUsername(loggedAccount.getUsername());
				cancella.setLoggedAccountPassword(loggedAccount.getPassword());

				cancella.setId(Long.parseLong(request.getParameter("id")));

				WSCancellaNotiziaStub.CancellaNotiziaResponse resCancella = null;
				try {
					resCancella = stubCancella.cancellaNotizia(cancella);
				} catch (RemoteException e) {
					if (e.getMessage().equals("100")) {
						throw new NoDBConnectionException();
					} else {
						throw new NoWSConnectionException(
								stubCancella.getClass());
					}
				}
				resCancella.get_return();
				courtesy = "messages.courtesy.success.cancellanotizia";
			}

		}
		return new ModelAndView("courtesyPage", "message", courtesy);
	}

}
