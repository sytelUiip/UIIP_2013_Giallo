package it.gruppogiallo.registranotizia;

import java.rmi.RemoteException;
import java.util.Properties;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.login.WSLoginStub.Account;
import it.gruppogiallo.visualizzanotizia.WSVisualizzaNotiziaStub;
import it.gruppogiallo.visualizzanotizia.WSVisualizzaNotiziaStub.Notizia;
import it.gruppogiallo.wsmanager.WSManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class RegistraNotiziaController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(RegistraNotiziaController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String courtesyMessage = "";
		logger.debug("Class RegistraNotiziaController - handleRequestInternal called in UI");
		Account loggedAccount = (Account) request.getSession().getAttribute(
				"account");
		// Code to add an enhanced security
		WSVisualizzaNotiziaStub stubVisNotizia = new WSVisualizzaNotiziaStub();
		WSVisualizzaNotiziaStub.VisualizzaNotizia visualizza = new WSVisualizzaNotiziaStub.VisualizzaNotizia();
		visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
		visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
		visualizza.setId(Long.parseLong(request.getParameter("id")));

		WSVisualizzaNotiziaStub.VisualizzaNotiziaResponse resVisualizza = stubVisNotizia
				.visualizzaNotizia(visualizza);
		Notizia notizia = new Notizia();
		notizia = resVisualizza.get_return();
		if ((!(loggedAccount.getSiglaGiornalista().equals(notizia
				.getUltimoDigitatore())))

		) {

			courtesyMessage = "messages.courtesy.fail.noaccess.registranotizia";
		} else {
			Properties wsManager = WSManager.getWSProperties();

			String serviceName = "WSRegistraNotizia";
			String wsEndpoint = "http://";
			wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
			wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
			wsEndpoint += wsManager.getProperty(serviceName + "-Base");
			wsEndpoint += "/services/" + serviceName + "." + serviceName
					+ "HttpSoap12Endpoint/";
			WSRegistraNotiziaStub stub = new WSRegistraNotiziaStub(null, wsEndpoint);
			WSRegistraNotiziaStub.RegistraNotizia registra = new WSRegistraNotiziaStub.RegistraNotizia();

			registra.setLoggedAccountUsername(loggedAccount.getUsername());
			registra.setLoggedAccountPassword(loggedAccount.getPassword());
			registra.setId(Long.parseLong(request.getParameter("id")));
			registra.setTitolo(request.getParameter("titolo"));
			registra.setSottotitolo(request.getParameter("sottotitolo"));
			registra.setTipologiaNotizia(request
					.getParameter("tipologiaNotizia"));
			registra.setTesto(request.getParameter("testo"));

			try {
				stub.registraNotizia(registra);
			} catch (RemoteException e) {
				if (e.getMessage().equals("100")) {
					throw new NoDBConnectionException();
				} else {
					throw new NoWSConnectionException(stub.getClass());
				}
			}

			courtesyMessage = "messages.courtesy.success.registranotizia";
		}

		return new ModelAndView("courtesyPage", "message", courtesyMessage);
	}

}
