package it.gruppogiallo.annullamodificanotizia;

import java.util.Properties;

import it.gruppogiallo.visualizzanotizia.WSVisualizzaNotiziaStub;
import it.gruppogiallo.visualizzanotizia.WSVisualizzaNotiziaStub.Notizia;
import it.gruppogiallo.wsmanager.WSManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class AnnullaModificaController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(AnnullaModificaController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String courtesyMessage = "";
		logger.debug("Class AnnullaModificaController - handleRequestInternal called in UI");
		Properties wsManager = WSManager.getWSProperties();
		String serviceName = "WSVisualizzaNotizia";
		String wsEndpoint = "http://";
		wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
		wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
		wsEndpoint += wsManager.getProperty(serviceName + "-Base");
		wsEndpoint += "/services/" + serviceName + "." + serviceName
				+ "HttpSoap12Endpoint/";
		
		
		WSVisualizzaNotiziaStub stubVisNotizia = new WSVisualizzaNotiziaStub(null,wsEndpoint);
		WSVisualizzaNotiziaStub.VisualizzaNotizia visualizza = new WSVisualizzaNotiziaStub.VisualizzaNotizia();
		it.gruppogiallo.login.WSLoginStub.Account loggedAccount = (it.gruppogiallo.login.WSLoginStub.Account) request
				.getSession().getAttribute("account");

		visualizza.setLoggedAccountUsername(loggedAccount.getUsername());
		visualizza.setLoggedAccountPassword(loggedAccount.getPassword());
		visualizza.setId(Long.parseLong(request.getParameter("id")));

		WSVisualizzaNotiziaStub.VisualizzaNotiziaResponse resVisualizza = stubVisNotizia
				.visualizzaNotizia(visualizza);
		Notizia notizia = new Notizia();
		notizia = resVisualizza.get_return();
		if ((!(loggedAccount.getSiglaGiornalista().equals(notizia
				.getUltimoDigitatore())))

		) {

			courtesyMessage = "messages.courtesy.fail.noaccess.annullanotizia";
		} else {
			
			serviceName = "WSAnnullaModificaNotizia";
			wsEndpoint = "http://";
			wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
			wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
			wsEndpoint += wsManager.getProperty(serviceName + "-Base");
			wsEndpoint += "/services/" + serviceName + "." + serviceName
					+ "HttpSoap12Endpoint/";
			WSAnnullaModificaNotiziaStub stub = new WSAnnullaModificaNotiziaStub();
			WSAnnullaModificaNotiziaStub.AnnullaModificaNotizia annullaModifica = new WSAnnullaModificaNotiziaStub.AnnullaModificaNotizia();
			annullaModifica.setLoggedAccountUsername(loggedAccount
					.getUsername());
			annullaModifica.setLoggedAccountPassword(loggedAccount
					.getPassword());
			annullaModifica.setId(Long.parseLong(request.getParameter("id")));
			WSAnnullaModificaNotiziaStub.AnnullaModificaNotiziaResponse res = stub
					.annullaModificaNotizia(annullaModifica);
			res.get_return();
			courtesyMessage = "messages.courtesy.success.annullanotizia";
		}

		return new ModelAndView("courtesyPage", "message", courtesyMessage);
	}
}
