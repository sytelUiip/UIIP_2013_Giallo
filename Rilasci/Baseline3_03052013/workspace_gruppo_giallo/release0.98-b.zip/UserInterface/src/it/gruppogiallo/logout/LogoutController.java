package it.gruppogiallo.logout;

import it.gruppogiallo.login.WSLoginStub.Account;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class LogoutController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(LogoutController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Account account = (Account) request.getSession()
				.getAttribute("account");
		logger.info("Account " + account.getUsername() + " logged out");
		logger.debug("Account " + account.getUsername() + " logged out");

		request.getSession().invalidate();
		return new ModelAndView("logout");
	}

}
