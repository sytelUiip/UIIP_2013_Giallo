package it.gruppogiallo.modificaaccount;

import it.gruppogiallo.exception.NoDBConnectionException;
import it.gruppogiallo.exception.NoWSConnectionException;
import it.gruppogiallo.login.WSLoginStub.Account;
import it.gruppogiallo.wsmanager.WSManager;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class ModificaAccountController extends AbstractController {

	private static final Logger logger = Logger
			.getLogger(ModificaAccountController.class);

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String courtesyMessage = "";
		logger.debug("Class ModificaAccountController - handleRequestInternal called in UI");
		Account loggedAccount = (Account) request.getSession().getAttribute(
				"account");
		if (
				loggedAccount.getUsername().equals(request.getParameter("usernameModificato")) &&
				request.getParameter("primoGruppo") == null
				
			) {
				courtesyMessage = "messages.courtesy.fail.noaccess.modificaaccount";
		} else {
			Properties wsManager = WSManager.getWSProperties();

			String serviceName = "WSModificaAccount";
			String wsEndpoint = "http://";
			wsEndpoint += wsManager.getProperty(serviceName + "-URL") + ":";
			wsEndpoint += wsManager.getProperty(serviceName + "-Port") + "/";
			wsEndpoint += wsManager.getProperty(serviceName + "-Base");
			wsEndpoint += "/services/" + serviceName + "." + serviceName
					+ "HttpSoap12Endpoint/";

			WSModificaAccountStub stub = new WSModificaAccountStub(null,
					wsEndpoint);
			WSModificaAccountStub.ModificaAccount modifica = new WSModificaAccountStub.ModificaAccount();
			modifica.setLoggedAccountUsername(loggedAccount.getUsername());
			modifica.setLoggedAccountPassword(loggedAccount.getPassword());
			modifica.setNome(request.getParameter("nome"));
			modifica.setCognome(request.getParameter("cognome"));
			modifica.setUsername(request.getParameter("usernameModificato"));
			modifica.setEmail(request.getParameter("email"));
			modifica.setSiglaRedazione(request.getParameter("siglaRedazione"));
			modifica.setSiglaGiornalista(request
					.getParameter("siglaGiornalista"));

			List<String> lista = new ArrayList<String>();

			if (request.getParameter("primoGruppo") != null
					&& request.getParameter("primoGruppo").equals("1")) {
				lista.add("AMMINISTRATORE");
			}
			if (request.getParameter("secondoGruppo") != null
					&& request.getParameter("secondoGruppo").equals("1")) {
				lista.add("GIORNALISTA");
			}

			String[] gruppi = new String[lista.size()];
			for (int i = 0; i < gruppi.length; i++)
				gruppi[i] = lista.get(i);

			modifica.setGruppi(gruppi);

			WSModificaAccountStub.ModificaAccountResponse res = null;
			try {
				res = stub.modificaAccount(modifica);
			} catch (RemoteException e) {
				if (e.getMessage().equals("100")) {
					throw new NoDBConnectionException();
				} else {
					throw new NoWSConnectionException(stub.getClass());
				}
			}
			boolean risultato = res.get_return();

			if (risultato)
				courtesyMessage = "messages.courtesy.success.modificaaccount";
			else
				courtesyMessage = "messages.courtesy.fail.modificaaccount";

			logger.debug("Account "
					+ request.getParameter("usernameModificato")
					+ " successfully modified");
			logger.info("Account " + request.getParameter("usernameModificato")
					+ " successfully modified");
		}
		return new ModelAndView("courtesyPage", "message", courtesyMessage);
	}

}
