package it.gruppogiallo.receiver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class ReceiverServlet extends HttpServlet {
	Scheduler scheduler = null;
	private static final long serialVersionUID = 1L;

	public ReceiverServlet() {
		super();
	}
	
	

	@Override
	public void destroy() {
		try {
			scheduler.shutdown();
		} catch (SchedulerException e) {
			e.printStackTrace();
		}
		super.destroy();
	}



	@Override
	public void init() throws ServletException {
		
		try {
			scheduler = StdSchedulerFactory.getDefaultScheduler();

			scheduler.start();

			JobDetail job = JobBuilder.newJob(Receiver.class)
					.withIdentity("job1", "group1").build();

			Trigger trigger = TriggerBuilder
					.newTrigger()
					.withIdentity("trigger1", "group1")
					.startNow()
					.withSchedule(
							SimpleScheduleBuilder.simpleSchedule()
									.withIntervalInSeconds(5).repeatForever())
					.build();

			scheduler.scheduleJob(job, trigger);

		} catch (SchedulerException e) {
			System.out.println(e.getMessage());
		}
		super.init();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

}
