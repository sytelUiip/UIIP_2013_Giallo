package it.gruppogiallo.receiver;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Notizia;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Receiver implements Job {

	private static final Logger logger = Logger.getLogger(Receiver.class);
	private static Document document;

	@Override
	public void execute(JobExecutionContext jExeCtx)
			throws JobExecutionException {
		exportXSDFiles();
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(true);
		DocumentBuilder builder;
		List<File> listaFile = getFiles();
		FileInputStream is = null;
		for (File file : listaFile) {
			try {
				builder = factory.newDocumentBuilder();
				is = new FileInputStream(file);
				document = builder.parse(is);
				logger.debug("RECEIVER: Found News: " + file.getName());
				logger.info("RECEIVER: Found News: " + file.getName());
				InputStream in = new FileInputStream(file);
				boolean validate = validateAgainstXSD(in);
				if (validate) {
					NodeList nodeTesto = stringQuery("//Testo");
					NodeList nodeAnagrafica = stringQuery("//Anagrafica");
					for (int i = 0; i < nodeTesto.getLength(); i++) {
						Node anagrafica = nodeAnagrafica.item(i);
						String titolo = anagrafica.getAttributes()
								.getNamedItem("Titolo").getTextContent();
						String sottotitolo = anagrafica.getAttributes()
								.getNamedItem("Sottotitolo").getTextContent();
						String dataCreazione = anagrafica.getAttributes()
								.getNamedItem("DataCreazione").getTextContent();
						Date data = convertToDate(dataCreazione);
						Node nome = nodeTesto.item(i);
						String testo = nome.getTextContent();
						Notizia notizia = new Notizia();
						notizia.setTitolo(titolo);
						notizia.setSottotitolo(sottotitolo);
						notizia.setAutore("RCV");
						notizia.setDataCreazione(data);
						notizia.setLunghezzaTesto(testo.length());
						notizia.setStato("S");
						notizia.setLockNotizia("N");
						notizia.setTesto(testo);
						SuperDAO dao = new SuperDAO();
						dao.createNotiziaEsterna(notizia);
					}
				} else {
					logger.warn("RECEIVER: File " + file.getName()
							+ " was not well formed");
					logger.info("RECEIVER: File " + file.getName()
							+ " was not well formed");
					rejectNews(file);
				}
				in.close();
				file.delete();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ParserConfigurationException e) {
			} catch (SAXException e) {
				logger.error("RECEIVER: File " + file.getName()
						+ " is not a XML file !");
				try {
					is.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				rejectNews(file);
			}
		}
	}

	public static NodeList stringQuery(String expr) {
		XPathFactory factory = XPathFactory.newInstance();
		XPath x = factory.newXPath();
		try {
			return (NodeList) x
					.evaluate(expr, document, XPathConstants.NODESET);
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		}
		return null;
	}

	static boolean validateAgainstXSD(InputStream xml) {

		InputStream xsd=null;
		try {
			xsd = new FileInputStream("C:/theyellowdaily/news/xsd/receiver.xsd");
		} catch (FileNotFoundException e) {
			logger.warn("RECEIVER - Validating file not found ");
		}
		boolean validating = false;
		try {
			SchemaFactory factory = SchemaFactory
					.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema schema = factory.newSchema(new StreamSource(xsd));
			Validator validator = schema.newValidator();
			validator.validate(new StreamSource(xml));
			validating = true;
			xsd.close();
			xml.close();
		} catch (Exception ex) {
			logger.warn(ex.getMessage());
		}
		return validating;
	}

	private Date convertToDate(String stringa) {
		DateFormat formatter = null;
		Date myConvertedDate = null;

		// conversione String a Date conversion
		formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		try {
			myConvertedDate = (Date) formatter.parse(stringa);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return myConvertedDate;
	}

	public List<File> getFiles() {
		String folder = "C:/theyellowdaily/news";
		String subFolder = "C:/theyellowdaily/news/incoming";
		// logger.debug("Batch acquisition of daily news");
		new File(folder).mkdir();
		new File(subFolder).mkdir();
		File incoming = new File(subFolder);
		File[] incomingFiles = incoming.listFiles();
		List<File> files = new ArrayList<File>();
		for (int i = 0; i < incomingFiles.length; i++) {
			files.add(incomingFiles[i]);
		}
		return files;

	}

	private void rejectNews(File file) {
		String folder = "C:/theyellowdaily/news/rejected";
		new File(folder).mkdir();
		File incoming = new File(folder);
		File file2 = new File(incoming.getAbsolutePath() + "/[REJECTED]_"
				+ file.getName());
		try {
			file2.createNewFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		try {
			InputStream in = new FileInputStream(file);
			OutputStream out = new FileOutputStream(file2);

			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			in.close();
			out.close();
		} catch (FileNotFoundException ex) {
			logger.error("RECEIVER: " + ex.getMessage());
		} catch (IOException e) {
			logger.error("RECEIVER: " + e.getMessage());
		}
		file.delete();
	}

	private void exportXSDFiles() { 
		String folder = "C:/theyellowdaily/news/xsd";
		new File(folder).mkdir();
		File incoming = new File(folder);
		File file2 = new File(incoming.getAbsolutePath()+ "/receiver.xsd");
		if(!(file2.exists())) {
			logger.info("RECEIVER - Creating validating XSD file in"+file2.getAbsolutePath());
			logger.debug("RECEIVER - Creating validating XSD file in"+file2.getAbsolutePath());
			try {
				file2.createNewFile();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			try {
				InputStream in = getClass().getResourceAsStream("/receiver.xsd");
				OutputStream out = new FileOutputStream(file2);
				
				byte[] buf = new byte[1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				in.close();
				out.close();
			} catch (FileNotFoundException ex) {
				logger.error("RECEIVER: " + ex.getMessage());
			} catch (IOException e) {
				logger.error("RECEIVER: " + e.getMessage());
			}	
		}
		
	}
}