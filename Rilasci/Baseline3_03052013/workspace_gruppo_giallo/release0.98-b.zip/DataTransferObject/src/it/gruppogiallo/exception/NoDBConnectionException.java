package it.gruppogiallo.exception;

import java.io.PrintStream;
import java.io.PrintWriter;

import org.apache.log4j.Logger;

public class NoDBConnectionException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger
			.getLogger(NoDBConnectionException.class);

	public NoDBConnectionException() {
		logger.error("NoDBConnectionException: unable to connect to DB");
	}

	public String getMessage() {
		return "100";
	}

	@Override
	public void printStackTrace(PrintStream s) {

	}

	@Override
	public void printStackTrace(PrintWriter s) {

	}

}
