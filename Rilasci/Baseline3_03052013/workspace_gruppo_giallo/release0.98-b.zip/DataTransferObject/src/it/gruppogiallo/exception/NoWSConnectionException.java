package it.gruppogiallo.exception;

import java.io.PrintStream;
import java.io.PrintWriter;

import org.apache.log4j.Logger;

public class NoWSConnectionException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger
			.getLogger(NoWSConnectionException.class);

	public NoWSConnectionException(Class<?> ws) {
		logger.error("NoWSConnectionException: unable to connect to WS - "
				+ ws.getSimpleName().substring(0,
						ws.getSimpleName().length() - 4));
	}

	public String getMessage() {
		return "300";
	}

	@Override
	public void printStackTrace(PrintStream s) {

	}

	@Override
	public void printStackTrace(PrintWriter s) {

	}

}
