package it.gruppogiallo.dto.test;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import it.gruppogiallo.entity.Notizia;


public class DTOTest {

	public static void main(String[] args) {
		// Test DTO class and log4j
		Notizia n1=new Notizia();
		Notizia n2=new Notizia();
		n1.setTesto("testo");
		n2.setTesto("testo");
		n1.setTitolo("titolo1");
		n2.setTitolo("titolo2");
		n1.setId(1);
		n2.setId(1);
		System.out.println(n1.equals(n2));
		
		System.out.println("ID1: "+n1.getId());
		Set<Notizia> notizie = new HashSet<Notizia>();
		
		notizie.add(n2);
		notizie.add(n1);
		System.out.println(notizie);
		
	}

}
