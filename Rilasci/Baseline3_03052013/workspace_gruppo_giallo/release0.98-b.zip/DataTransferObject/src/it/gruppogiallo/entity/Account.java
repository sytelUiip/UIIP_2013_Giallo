package it.gruppogiallo.entity;

/*import org.apache.log4j.Logger;*/

public class Account extends DTO {

	private static final long serialVersionUID = 1L;
	/* private static final Logger logger = Logger.getLogger(Account.class); */
	private String username;
	private String password;
	private String nome;
	private String cognome;
	private String email;
	private String siglaRedazione;
	private String siglaGiornalista;
	private String stato;
	private Gruppo[] gruppi;

	public Account(String username, String password, String nome,
			String cognome, String email, String siglaRedazione,
			String siglaGiornalista, String stato) {
		super();
		this.username = username;
		this.password = password;
		this.nome = nome;
		this.cognome = cognome;
		this.email = email;
		this.siglaRedazione = siglaRedazione;
		this.siglaGiornalista = siglaGiornalista;
		this.stato = stato;
		/*
		 * logger.debug("Class: Account - " + " constructor called in DTO");
		 * logger.debug("Account Parameters: " + " Username(" + username +
		 * ") Nome(" + nome + ") Cognome(" + username + ") " + "eMail(" + email
		 * + ") siglaRedazione(" + siglaRedazione + ") siglaGiornalista(" +
		 * siglaGiornalista + ") Stato("+stato+")");
		 */
	}

	public Account() {
		/*
		 * logger.debug("Class: Account - " +
		 * " void constructor called in DTO");
		 */
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSiglaRedazione() {
		return siglaRedazione;
	}

	public void setSiglaRedazione(String siglaRedazione) {
		this.siglaRedazione = siglaRedazione;
	}

	public String getSiglaGiornalista() {
		return siglaGiornalista;
	}

	public void setSiglaGiornalista(String siglaGiornalista) {
		this.siglaGiornalista = siglaGiornalista;
	}

	public String getStato() {
		return stato;
	}

	public void setStato(String stato) {
		this.stato = stato;
	}

	public Gruppo[] getGruppi() {
		return gruppi;
	}

	public void setGruppi(Gruppo[] gruppi) {
		this.gruppi = gruppi;
	}

	@Override
	public String toString() {
		return this.username + " " + this.password + " " + this.nome + " "
				+ this.cognome + " " + this.email + " " + this.siglaRedazione
				+ " " + this.siglaGiornalista + " " + this.stato + "\n"
				+ this.gruppi + "\n";
	}
}
