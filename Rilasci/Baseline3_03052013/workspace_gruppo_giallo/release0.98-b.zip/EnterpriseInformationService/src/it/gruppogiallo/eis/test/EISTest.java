package it.gruppogiallo.eis.test;
import it.gruppogiallo.dao.impl.SuperDAO;

public class EISTest {
	public static void main(String[] args) {
		
		SuperDAO dao = new SuperDAO();
		System.out.println(dao.visualizzaNotizia(81));
		System.out.println(dao.ricercaNotiziePerStatoNOLIMIT("S"));
	}

}
