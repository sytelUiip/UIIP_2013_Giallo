package it.gruppogiallo.dao.impl;

import it.gruppogiallo.calls.CallsManager;
import it.gruppogiallo.connection.ConnectionManager;
import it.gruppogiallo.entity.Account;
import it.gruppogiallo.entity.Funzionalita;
import it.gruppogiallo.entity.Gruppo;
import it.gruppogiallo.entity.Notizia;
import it.gruppogiallo.md5.MD5Hash;

import java.security.NoSuchAlgorithmException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import oracle.jdbc.OracleTypes;

import org.apache.log4j.Logger;

public class SuperDAO {

	private Connection conn;
	private Properties calls;
	private static final Logger logger = Logger.getLogger(SuperDAO.class);

	public SuperDAO() {
		conn = ConnectionManager.getConnection();
		calls = CallsManager.getCallsProperties();
	}

	public boolean createAccount(Account account) {

		logger.debug("Class: SuperDAO - Method: createAccount "
				+ " called in EIS");
		boolean exist = false;
		if (!(getAccountFromUsername(account.getUsername()) != null)) {
			try {
				CallableStatement stmt = conn.prepareCall(calls
						.getProperty("createAccount"));
				stmt.setString(1, account.getUsername());
				stmt.setString(2, MD5Hash.generate(account.getPassword()));
				stmt.setString(3, account.getNome());
				stmt.setString(4, account.getCognome());
				stmt.setString(5, account.getEmail());
				stmt.setString(6, account.getSiglaRedazione());
				stmt.setString(7, account.getSiglaGiornalista());
				stmt.setString(8, account.getStato());
				stmt.execute();
				logger.info("New Account created with username: "
						+ account.getUsername());
				logger.info("New Account created");
			} catch (SQLException e) {
				logger.error("Connection Failed");
				logger.error("Exception message:" + e.getMessage());
			} catch (NoSuchAlgorithmException e) {
				logger.error("MD5Hash: cannot find the algorythm specified");
				logger.error("Exception message:" + e.getMessage());
			}
			inserimentoAppartenenzaGruppo(account.getUsername(), "GIORNALISTA");
			exist = true;
		}
		return exist;
	}

	public Account getAccountFromUsername(String username) {
		logger.debug("Class: SuperDAO - Method: getAccountFromUsername "
				+ " called in EIS");
		Account accounts = null;
		CallableStatement stmt;
		try {
			stmt = conn
					.prepareCall(calls.getProperty("getAccountFromUsername"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, username);
			stmt.execute();
			ResultSet rs = (ResultSet) stmt.getObject(1);
			;
			while (rs.next()) {
				accounts = new Account(rs.getString("USERNAME"),
						rs.getString("PASSWORD"), rs.getString("NOME"),
						rs.getString("COGNOME"), rs.getString("EMAIL"),
						rs.getString("SIGLA_REDAZIONE"),
						rs.getString("SIGLA_GIORNALISTA"),
						rs.getString("STATO"));

			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		if (accounts != null) {
			List<Gruppo> temp = getGruppiByUsername(username);
			accounts.setGruppi(temp.toArray(new Gruppo[temp.size()]));
		} else {
			logger.debug("Account with username " + username + " not found");
		}
		return accounts;
	}

	public Account getAccountFromCredential(String username, String password) {
		logger.debug("Class: SuperDAO - Method: getAccountFromCredential "
				+ " called in EIS");
		Account accounts = null;
		CallableStatement stmt;
		try {
			stmt = conn.prepareCall(calls
					.getProperty("getAccountFromCredential"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, username);

			stmt.setString(3, password);

			stmt.execute();
			ResultSet rs = (ResultSet) stmt.getObject(1);
			while (rs.next()) {
				accounts = new Account(rs.getString("USERNAME"),
						rs.getString("PASSWORD"), rs.getString("NOME"),
						rs.getString("COGNOME"), rs.getString("EMAIL"),
						rs.getString("SIGLA_REDAZIONE"),
						rs.getString("SIGLA_GIORNALISTA"),
						rs.getString("STATO"));

			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		if (accounts != null) {
			List<Gruppo> temp = getGruppiByUsername(username);
			accounts.setGruppi(temp.toArray(new Gruppo[temp.size()]));
		} else {
			logger.debug("Account with username " + username + " not found");
		}
		return accounts;
	}

	public List<Account> getAccounts() {
		logger.debug("Class: SuperDAO - Method: getAccounts "
				+ " called in EIS");
		List<Account> accounts = new ArrayList<Account>();
		CallableStatement stmt;
		try {
			stmt = conn.prepareCall(calls.getProperty("getAccounts"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.execute();
			ResultSet rs;

			rs = (ResultSet) stmt.getObject(1);
			while (rs.next()) {
				Account temp_acc = new Account(rs.getString("USERNAME"),
						rs.getString("PASSWORD"), rs.getString("NOME"),
						rs.getString("COGNOME"), rs.getString("EMAIL"),
						rs.getString("SIGLA_REDAZIONE"),
						rs.getString("SIGLA_GIORNALISTA"),
						rs.getString("STATO"));

				List<Gruppo> temp = getGruppiByUsername(rs
						.getString("USERNAME"));

				temp_acc.setGruppi(temp.toArray(new Gruppo[temp.size()]));
				accounts.add(temp_acc);
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return accounts;
	}

	public Account getLogin(String username, String password) {
		logger.debug("Class: SuperDAO - " + " Method getLogin called in EIS");
		logger.debug("Username:" + username);
		Account accounts = null;
		CallableStatement stmt;
		try {
			stmt = conn.prepareCall(calls.getProperty("getLogin"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, username);
			stmt.setString(3, MD5Hash.generate(password));
			stmt.execute();
			ResultSet rs = (ResultSet) stmt.getObject(1);
			;
			while (rs.next()) {
				accounts = new Account(rs.getString("USERNAME"),
						rs.getString("PASSWORD"), rs.getString("NOME"),
						rs.getString("COGNOME"), rs.getString("EMAIL"),
						rs.getString("SIGLA_REDAZIONE"),
						rs.getString("SIGLA_GIORNALISTA"),
						rs.getString("STATO"));
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message: " + e.getMessage());
		} catch (NoSuchAlgorithmException e) {
			logger.error("MD5Hash: cannot find the algorythm specified");
			logger.error("Exception message:" + e.getMessage());
		}
		if (accounts != null) {
			List<Gruppo> temp = getGruppiByUsername(username);
			accounts.setGruppi(temp.toArray(new Gruppo[temp.size()]));
		} else {
			logger.debug("Account with username " + username + " not found");
		}
		return accounts;
	}

	public boolean isRegistered(String username) {
		logger.debug("Class: SuperDAO - "
				+ " Method isRegistered called in EIS");
		logger.debug("Username: " + username);
		return (getAccountFromUsername(username) != null);
	}

	public List<Gruppo> getGruppiByUsername(String username) {
		logger.debug("Class: SuperDAO - "
				+ " Method getGruppiByUsername called in EIS");
		logger.debug("Username:" + username);
		List<Gruppo> gruppi = new ArrayList<Gruppo>();
		CallableStatement stmt;
		try {
			stmt = conn.prepareCall(calls.getProperty("getGruppiByUsername"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, username);
			stmt.execute();
			ResultSet rs;

			rs = (ResultSet) stmt.getObject(1);
			while (rs.next()) {
				gruppi.add(new Gruppo(rs.getString("NOME_GRUPPO")));
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return gruppi;
	}

	public boolean aggiungiAppartenenzaGruppo(String username, String nomeGruppo) {
		logger.debug("Class: SuperDAO - "
				+ " Method aggiungiAppartenenzaGruppo called in EIS");
		logger.debug("Username: " + username);
		boolean result = false;
		Account account = getAccountFromUsername(username);
		try {
			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("insertNuovogruppo"));
			stmt.setString(1, account.getUsername());
			Gruppo[] gruppi = account.getGruppi();
			Gruppo[] temp = new Gruppo[gruppi.length + 1];
			for (int i = 0; i < temp.length; i++) {
				temp[i] = new Gruppo("");
			}

			if (gruppi[0] == null) {
				temp[0].setNomeGruppo(nomeGruppo);
				stmt.setString(2, temp[0].getNomeGruppo());
			} else {
				temp[0].setNomeGruppo(gruppi[0].getNomeGruppo());
				temp[1].setNomeGruppo(nomeGruppo);
				stmt.setString(2, temp[1].getNomeGruppo());
			}
			account.setGruppi(temp);
			stmt.execute();
			result = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return result;

	}

	public boolean inserimentoAppartenenzaGruppo(String username,
			String nomeGruppo) {
		logger.debug("Class: SuperDAO - "
				+ " Method inserimentoAppartenenzaGruppo called in EIS");
		logger.debug("Username: " + username);
		boolean result = false;
		Account account = getAccountFromUsername(username);
		try {
			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("insertNuovogruppo"));
			stmt.setString(1, account.getUsername());
			Gruppo[] gruppi = account.getGruppi();
			Gruppo[] temp = new Gruppo[gruppi.length + 1];
			for (int i = 0; i < temp.length; i++) {
				temp[i] = new Gruppo("");
			}
			temp[0].setNomeGruppo(nomeGruppo);
			stmt.setString(2, temp[0].getNomeGruppo());

			account.setGruppi(temp);

			stmt.execute();
			result = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return result;

	}

	public boolean modificaAccount(String username, String nome,
			String cognome, String email, String siglaRedazione,
			String siglaGiornalista) {
		logger.debug("Class: SuperDAO - "
				+ " Method modificaAccount called in EIS");
		logger.debug("Account modified Parameters: " + " Username(" + username
				+ ") Nome(" + nome + ") Cognome(" + username + ") " + "eMail("
				+ email + ") siglaRedazione(" + siglaRedazione
				+ ") siglaGiornalista(" + siglaGiornalista + ")");
		CallableStatement stmt;
		boolean result = false;
		try {
			stmt = conn.prepareCall(CallsManager.getCallsProperties()
					.getProperty("modificaAccount"));

			stmt.setString(1, username);
			stmt.setString(2, nome);
			stmt.setString(3, cognome);
			stmt.setString(4, email);
			stmt.setString(5, siglaRedazione);
			stmt.setString(6, siglaGiornalista);
			stmt.execute();
			stmt.close();
			result = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return result;
	}

	public boolean cancellaAppartenenzaGruppo(String username) {
		logger.debug("Class: SuperDAO - "
				+ " Method cancellaAppartenenzaGruppo called in EIS");
		logger.debug("Username: " + username);
		boolean result = false;
		CallableStatement stmt;
		try {
			stmt = conn.prepareCall(CallsManager.getCallsProperties()
					.getProperty("cancellaAppartenenzaGruppo"));
			stmt.setString(1, username);
			stmt.execute();
			result = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return result;
	}

	public boolean aggiornaAppartenenzaGruppo(String username,
			List<Gruppo> gruppi) {
		logger.debug("Class: SuperDAO - "
				+ " Method aggiornaAppartenenzaGruppo called in EIS");
		logger.debug("Username: " + username);
		// non � possibile avere account a cui non � associato nessun gruppo di
		// appartenenza
		boolean execute = false;
		if (gruppi.size() != 0) {
			cancellaAppartenenzaGruppo(username);
			for (Gruppo g : gruppi) {
				inserimentoAppartenenzaGruppo(username, g.getNomeGruppo());
			}
			execute = true;
		}
		return execute;
	}

	public List<Funzionalita> listaFunzionalitabyUsername(String username) {
		logger.debug("Class: SuperDAO - "
				+ " Method listaFunzionalitabyUsername called in EIS");
		logger.debug("Username: " + username);
		List<Funzionalita> funzionalita = new ArrayList<Funzionalita>();
		CallableStatement stmt;
		try {
			stmt = conn.prepareCall(CallsManager.getCallsProperties()
					.getProperty("listaFunzionalitabyUsername"));

			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, username);
			stmt.execute();
			ResultSet rs;
			rs = (ResultSet) stmt.getObject(1);

			while (rs.next()) {
				String siglaFunzionalita = rs.getString("SIGLA_FUNZIONALITA");
				String nomeFunzionalita = rs.getString("NOME_FUNZIONALITA");
				String nomeGruppo = rs.getString("NOME_GRUPPO");
				Gruppo gruppo = new Gruppo(nomeGruppo);
				funzionalita.add(new Funzionalita(siglaFunzionalita,
						nomeFunzionalita, gruppo));
			}

			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return funzionalita;
	}

	public boolean cancellaAccount(String username) {
		logger.debug("Class: SuperDAO - "
				+ " Method cancellaAccount called in EIS");
		logger.debug("Username: " + username);
		boolean result = false;
		List<Gruppo> gruppi = new ArrayList<Gruppo>();
		gestioneCancellaNotizia(username);
		try {
			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("cancellaAccount"));
			stmt.setString(1, username);
			stmt.execute();
			cancellaAppartenenzaGruppo(username);
			gruppi = getGruppiByUsername(username);
			if (gruppi.size() == 0) {
				result = true;
				logger.info("Account with username " + username + " deleted");
				logger.debug("Account with username " + username + " deleted");
			} else {
				logger.info("Account with username " + username
						+ " not deleted");
				logger.debug("Account with username " + username
						+ " not deleted");
				logger.warn("Cannot delete account with username " + username
						+ ". Check Method cancellaAccount");
			}
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return result;
	}

	public boolean gestioneCancellaNotizia(String username) {
		logger.debug("Class: SuperDAO - "
				+ " Method gestioneCancellaNotizia called in EIS");
		String ultimoDigitatore = getSiglaGiornalista(username);
		List<Long> idNotizie = new ArrayList<Long>();
		idNotizie = getIdNotiziaBloccataByUltimoDig(ultimoDigitatore);
		return sbloccaNotizia(idNotizie);
	}

	public String getSiglaGiornalista(String username) {
		logger.debug("Class: SuperDAO - "
				+ " Method getSiglaGiornalista called in EIS");
		logger.debug("Username: " + username);
		String sigla = "";
		CallableStatement stmt;
		try {
			stmt = conn.prepareCall(calls.getProperty("getSiglaGiornalista"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, username);
			stmt.execute();
			ResultSet rs = (ResultSet) stmt.getObject(1);
			while (rs.next()) {
				sigla = rs.getString("SIGLA_GIORNALISTA");
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}

		return sigla;
	}

	public List<Long> getIdNotiziaBloccataByUltimoDig(String ultimoDigitatore) {
		logger.debug("Class: SuperDAO - "
				+ " Method getIdNotiziaBloccataByUltimoDig called in EIS");
		List<Long> idNotizie = new ArrayList<Long>();
		CallableStatement stmt;
		try {
			stmt = conn.prepareCall(calls
					.getProperty("getIdNotiziaBloccataByUltimoDig"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, ultimoDigitatore);
			stmt.execute();
			ResultSet rs = (ResultSet) stmt.getObject(1);

			while (rs.next()) {
				idNotizie.add(rs.getLong("ID"));
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}

		return idNotizie;
	}

	public boolean sbloccaNotizia(List<Long> idLista) {
		logger.debug("Class: SuperDAO - "
				+ " Method getIdNotiziaBloccataByUltimoDig called in EIS");
		boolean result = false;
		try {
			for (int i = 0; i < idLista.size(); i++) {

				CallableStatement stmt = conn.prepareCall(CallsManager
						.getCallsProperties().getProperty("sbloccaNotizia"));

				stmt.setLong(1, idLista.get(i));
				stmt.execute();
			}
			result = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return result;
	}

	public boolean createNotizia(Notizia notizia, String username) {
		logger.debug("Class: SuperDAO - Method: createNotizia "
				+ " called in EIS");
		boolean result = false;
		try {
			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("createNotizia"));
			String autore;

			autore = getSiglaGiornalista(username);

			stmt.setString(1, notizia.getStato());
			stmt.setString(2, notizia.getLockNotizia());
			stmt.setString(3, notizia.getTitolo());
			stmt.setString(4, notizia.getSottotitolo());
			stmt.setString(5, notizia.getTipologiaNotizia());
			stmt.setString(6, autore);
			stmt.setString(7, notizia.getUltimoDigitatore());
			stmt.setString(8, notizia.getTesto());
			stmt.setInt(9, notizia.getLunghezzaTesto());
			stmt.execute();
			result = true;

			logger.info("New Notizia created: " + notizia.getTitolo());
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}

		return result;

	}

	public boolean createNotiziaEsterna(Notizia notizia) {
		logger.debug("Class: SuperDAO - Method: createNotizia "
				+ " called in EIS");
		boolean result = false;
		try {
			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("createNotizia"));

			stmt.setString(1, notizia.getStato());
			stmt.setString(2, notizia.getLockNotizia());
			stmt.setString(3, notizia.getTitolo());
			stmt.setString(4, notizia.getSottotitolo());
			stmt.setString(5, notizia.getTipologiaNotizia());
			stmt.setString(6, notizia.getAutore());
			stmt.setString(7, notizia.getUltimoDigitatore());
			stmt.setString(8, notizia.getTesto());
			stmt.setInt(9, notizia.getLunghezzaTesto());
			stmt.execute();
			result = true;

			logger.info("New Notizia created");
			logger.info("New notizia created");
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}

		return result;

	}

	public List<Notizia> ricercaNotiziePerStato(String stato, int minLimit,
			int maxLimit) {
		List<Notizia> notizie = new ArrayList<Notizia>();
		Notizia notizia = null;
		try {

			CallableStatement stmt = conn.prepareCall(calls
					.getProperty("ricercaNotiziePerStato"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, stato);
			stmt.setInt(3, minLimit);
			stmt.setInt(4, maxLimit);
			stmt.execute();
			ResultSet rs;
			rs = (ResultSet) stmt.getObject(1);
			while (rs.next()) {

				notizia = new Notizia();
				notizia.setId(rs.getLong("id"));
				notizia.setTitolo(rs.getString("titolo"));
				notizia.setSottotitolo(rs.getString("sottotitolo"));
				notizia.setAutore(rs.getString("autore"));
				notizia.setTipologiaNotizia(rs.getString("tipologia_notizia"));
				notizia.setDataCreazione(rs.getDate("data_creazione"));
				notizia.setDataTrasmissione(rs.getDate("data_trasmissione"));
				notizia.setStato(rs.getString("stato"));
				notizia.setTesto(rs.getString("testo"));
				notizia.setLunghezzaTesto(rs.getInt("lunghezza_testo"));
				notizia.setLockNotizia(rs.getString("lock_notizia"));
				notizia.setUltimoDigitatore(rs.getString("ultimo_digitatore"));

				notizie.add(notizia);
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return notizie;
	}

	public List<Notizia> ricercaNotiziePerStatoNOLIMIT(String stato) {
		/*
		 * logger.debug("Class: SuperDAO - Method: ricercaNotiziePerStato " +
		 * " called in EIS");
		 */
		List<Notizia> notizie = new ArrayList<Notizia>();
		Notizia notizia = null;
		try {

			CallableStatement stmt = conn.prepareCall(calls
					.getProperty("ricercaNotiziePerStatoNoLimit"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, stato);
			stmt.execute();
			ResultSet rs;
			rs = (ResultSet) stmt.getObject(1);
			while (rs.next()) {

				notizia = new Notizia();
				notizia.setId(rs.getLong("id"));
				notizia.setTitolo(rs.getString("titolo"));
				notizia.setSottotitolo(rs.getString("sottotitolo"));
				notizia.setAutore(rs.getString("autore"));
				notizia.setTipologiaNotizia(rs.getString("tipologia_notizia"));
				notizia.setDataCreazione(rs.getDate("data_creazione"));
				notizia.setDataTrasmissione(rs.getDate("data_trasmissione"));
				notizia.setStato(rs.getString("stato"));
				notizia.setTesto(rs.getString("testo"));
				notizia.setLunghezzaTesto(rs.getInt("lunghezza_testo"));
				notizia.setLockNotizia(rs.getString("lock_notizia"));
				notizia.setUltimoDigitatore(rs.getString("ultimo_digitatore"));

				notizie.add(notizia);
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
			e.printStackTrace();
		}
		return notizie;
	}

	public boolean changeStatoNotizia(long id, String stato) {

		logger.debug("Class: SuperDAO - Method: sendNotizia "
				+ " called in EIS");
		boolean ret = false;
		try {

			CallableStatement stmt = conn.prepareCall(calls
					.getProperty("changeStatoNotizia"));
			stmt.setLong(1, id);
			stmt.setString(2, stato);
			stmt.execute();
			ret = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return ret;
	}

	public List<Notizia> listaNotizie(int minLimit, int maxLimit) {
		logger.debug("Class: SuperDAO - Method: listaNotizie "
				+ " called in EIS");
		List<Notizia> notizie = new ArrayList<Notizia>();
		CallableStatement stmt;
		try {

			stmt = conn.prepareCall(calls.getProperty("listaNotizie"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setLong(2, minLimit);
			stmt.setLong(3, maxLimit);
			stmt.execute();
			ResultSet rs;
			rs = (ResultSet) stmt.getObject(1);
			while (rs.next()) {

				Notizia notizia = new Notizia();
				notizia.setId(rs.getLong("id"));
				notizia.setTitolo(rs.getString("titolo"));
				notizia.setSottotitolo(rs.getString("sottotitolo"));
				notizia.setAutore(rs.getString("autore"));
				notizia.setTipologiaNotizia(rs.getString("tipologia_notizia"));
				notizia.setDataCreazione(rs.getDate("data_creazione"));
				notizia.setDataTrasmissione(rs.getDate("data_trasmissione"));
				notizia.setStato(rs.getString("stato"));
				notizia.setTesto(rs.getString("testo"));
				notizia.setLunghezzaTesto(rs.getInt("lunghezza_testo"));
				notizia.setLockNotizia(rs.getString("lock_notizia"));
				notizia.setUltimoDigitatore(rs.getString("ultimo_digitatore"));

				notizie.add(notizia);
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return notizie;
	}

	public List<Notizia> ricercaNotiziePerAutore(String autore, int minLimit,
			int maxLimit) {
		logger.debug("Class: SuperDAO - Method: ricercaNotiziePerAutore "
				+ " called in EIS");
		List<Notizia> notizie = new ArrayList<Notizia>();
		Notizia notizia = null;
		try {

			CallableStatement stmt = conn.prepareCall(calls
					.getProperty("ricercaNotiziePerAutore"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, autore);
			stmt.setInt(3, minLimit);
			stmt.setInt(4, maxLimit);
			stmt.execute();
			ResultSet rs;
			rs = (ResultSet) stmt.getObject(1);
			while (rs.next()) {

				notizia = new Notizia();
				notizia.setId(rs.getLong("id"));
				notizia.setTitolo(rs.getString("titolo"));
				notizia.setSottotitolo(rs.getString("sottotitolo"));
				notizia.setAutore(rs.getString("autore"));
				notizia.setTipologiaNotizia(rs.getString("tipologia_notizia"));
				notizia.setDataCreazione(rs.getDate("data_creazione"));
				notizia.setDataTrasmissione(rs.getDate("data_trasmissione"));
				notizia.setStato(rs.getString("stato"));
				notizia.setTesto(rs.getString("testo"));
				notizia.setLunghezzaTesto(rs.getInt("lunghezza_testo"));
				notizia.setLockNotizia(rs.getString("lock_notizia"));
				notizia.setUltimoDigitatore(rs.getString("ultimo_digitatore"));
				notizie.add(notizia);
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return notizie;
	}

	public List<Notizia> ricercaNotiziePerTitolo(String titolo, int minLimit,
			int maxLimit) {
		logger.debug("Class: SuperDAO - Method: ricercaNotiziePerTitolo "
				+ " called in EIS");
		List<Notizia> notizie = new ArrayList<Notizia>();
		Notizia notizia = null;
		try {

			CallableStatement stmt = conn.prepareCall(calls
					.getProperty("ricercaNotiziePerTitolo"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, titolo);
			stmt.setInt(3, minLimit);
			stmt.setInt(4, maxLimit);
			stmt.execute();
			ResultSet rs;
			rs = (ResultSet) stmt.getObject(1);
			while (rs.next()) {

				notizia = new Notizia();
				notizia.setId(rs.getLong("id"));
				notizia.setTitolo(rs.getString("titolo"));
				notizia.setSottotitolo(rs.getString("sottotitolo"));
				notizia.setAutore(rs.getString("autore"));
				notizia.setTipologiaNotizia(rs.getString("tipologia_notizia"));
				notizia.setDataCreazione(rs.getDate("data_creazione"));
				notizia.setDataTrasmissione(rs.getDate("data_trasmissione"));
				notizia.setStato(rs.getString("stato"));
				notizia.setTesto(rs.getString("testo"));
				notizia.setLunghezzaTesto(rs.getInt("lunghezza_testo"));
				notizia.setLockNotizia(rs.getString("lock_notizia"));
				notizia.setUltimoDigitatore(rs.getString("ultimo_digitatore"));

				notizie.add(notizia);
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return notizie;
	}

	public Notizia visualizzaNotizia(long id) {

		logger.debug("Class: SuperDAO - Method: visualizzaNotizia "
				+ " called in EIS");

		Notizia notizia = null;
		CallableStatement stmt;
		try {

			stmt = conn.prepareCall(calls.getProperty("visualizzaNotizia"));
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setLong(2, id);
			stmt.execute();
			ResultSet rs;
			rs = (ResultSet) stmt.getObject(1);
			while (rs.next()) {
				notizia = new Notizia();
				notizia.setId(rs.getLong("id"));
				notizia.setTitolo(rs.getString("titolo"));
				notizia.setSottotitolo(rs.getString("sottotitolo"));
				notizia.setAutore(rs.getString("autore"));
				notizia.setTipologiaNotizia(rs.getString("tipologia_notizia"));
				notizia.setDataCreazione(rs.getDate("data_creazione"));
				notizia.setDataTrasmissione(rs.getDate("data_trasmissione"));
				notizia.setStato(rs.getString("stato"));
				notizia.setTesto(rs.getString("testo"));
				notizia.setLunghezzaTesto(rs.getInt("lunghezza_testo"));
				notizia.setLockNotizia(rs.getString("lock_notizia"));
				notizia.setUltimoDigitatore(rs.getString("ultimo_digitatore"));

			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}

		return notizia;
	}

	public boolean cancellaNotizia(long id) {
		logger.debug("Class: SuperDAO - "
				+ " Method cancellaNotizia called in EIS");
		logger.debug("id: " + id);
		boolean result = false;
		try {

			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("cancellaNotizia"));
			stmt.setLong(1, id);
			stmt.execute();
			result = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}

		return result;

	}

	public boolean modificaNotizia(long id, String ultimoDigitatore) {
		logger.debug("Class: SuperDAO - "
				+ " Method modificaNotizia called in EIS");
		logger.debug("id: " + id);
		boolean result = false;
		try {

			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("modificaNotizia"));
			stmt.setLong(1, id);
			stmt.setString(2, ultimoDigitatore);
			stmt.execute();
			result = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return result;
	}

	public boolean registraNotizia(long id, String titolo, String sottotitolo,
			String tipologiaNotizia, String testo, int lunghezzaTesto) {
		logger.debug("Class: SuperDAO - "
				+ " Method registraNotizia called in EIS");
		/*logger.debug("Notizia modified Parameters: " + " Titolo(" + titolo
				+ ") Sottotitolo(" + sottotitolo + ") TipologiaNotizia("
				+ tipologiaNotizia + ") " + "Testo(" + testo
				+ ") LunghezzaTesto(" + lunghezzaTesto + ")");*/
		CallableStatement stmt;
		boolean result = false;
		try {
			stmt = conn.prepareCall(CallsManager.getCallsProperties()
					.getProperty("registraNotizia"));

			stmt.setLong(1, id);
			stmt.setString(2, titolo);
			stmt.setString(3, sottotitolo);
			stmt.setString(4, tipologiaNotizia);
			stmt.setString(5, testo);
			stmt.setInt(6, lunghezzaTesto);
			stmt.execute();
			stmt.close();
			result = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}
		return result;
	}

	public boolean trasmettiNotizia(long id) {
		logger.debug("Class: SuperDAO - "
				+ " Method trasmettiNotizia called in EIS");
		logger.debug("id: " + id);
		boolean result = false;
		try {

			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("trasmettiNotizia"));
			stmt.setLong(1, id);
			stmt.execute();
			result = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}

		return result;

	}

	public boolean annullaModifica(long id) {
		logger.debug("Class: SuperDAO - "
				+ " Method annullaModifica called in EIS");
		logger.debug("id: " + id);
		boolean result = false;
		try {

			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("annullaModifica"));
			stmt.setLong(1, id);
			stmt.execute();
			result = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}

		return result;

	}

	public boolean sbloccaNotizieByUsername(String username) {
		logger.debug("Class: SuperDAO - "
				+ " Method sbloccaNotizieByUsername called in EIS");
		logger.debug("username: " + username);
		boolean result = false;
		try {
			String ultimoDigitatore = getSiglaGiornalista(username);
			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty(
							"sbloccaNotizieByUsername"));
			stmt.setString(1, ultimoDigitatore);
			stmt.execute();
			result = true;
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}

		return result;
	}
	
	public boolean cancellazioneEffettivaAccount(String username){	
		logger.debug("Class: SuperDAO - "
				+ " Method cancellazioneEffettivaAccount called in EIS");
		logger.debug("username: " + username);		
		boolean result = false;
		try {				
			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("cancellazioneEffettivaAccount"));		
				stmt.setString(1, username );
				stmt.execute();		
				cancellaAppartenenzaGruppo(username);
			result=true;
					} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}		

		return result;
}
	public boolean cancellazioneEffettivaNotizia(String username){	
		logger.debug("Class: SuperDAO - "
				+ " Method cancellazioneEffettivaNotizia called in EIS");
		logger.debug("username: " + username);		
		boolean result = false;
		try {
			String siglaGiornalista= getSiglaGiornalista(username);
			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("cancellazioneEffettivaNotizia"));
			
				stmt.setString(1, siglaGiornalista);
			
				stmt.execute();
			result=true;
	
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}		
		return result;
		
	}
	
	public boolean cancellazioneEffettivaNotiziaEsterna(String autore){	
		logger.debug("Class: SuperDAO - "
				+ " Method cancellazioneEffettivaNotizia called in EIS");
		logger.debug("autore: " + autore);		
		boolean result = false;
		try {					
			CallableStatement stmt = conn.prepareCall(CallsManager
					.getCallsProperties().getProperty("cancellazioneEffettivaNotizia"));					
				stmt.setString(1, autore);					
				stmt.execute();
			result=true;
	
		} catch (SQLException e) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + e.getMessage());
		}		
	return result;
}
	
}