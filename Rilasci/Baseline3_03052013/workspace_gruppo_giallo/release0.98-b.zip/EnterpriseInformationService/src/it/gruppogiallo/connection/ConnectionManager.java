package it.gruppogiallo.connection;

import it.gruppogiallo.exception.NoDBConnectionException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class ConnectionManager {

	private static Properties connectionProperties = null;
	private static Connection conn = null;
	private static ConnectionManager instance = null;
	private static final Logger logger = Logger
			.getLogger(ConnectionManager.class);

	private ConnectionManager() {
		connectionProperties = new Properties();
		writeConnectionPropertiesFile();
		connect();
		logger.debug("SINGLETON: ConnectionManager - " + " instantiated in EIS");
	}

	public static Connection getConnection() {
		if (instance == null)
			instance = new ConnectionManager();
		return conn;
	}

	private void loadConnectionConf() {

		Properties dbProps = new Properties();
		String in_filename = "connection.properties";
		FileInputStream is=null;
		try {
			is = new FileInputStream("C:/theyellowdaily/conf/"+in_filename);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		if (null == is) {
			logger.error("SINGLETON: ConnectionManager - method loadConnectionConf - "
					+ " filename " + in_filename + " not exist ");
		}
		try {
			dbProps.load(is);
			connectionProperties = dbProps;
		} catch (IOException ioe) {
			logger.error("properties loading failed ");
			logger.error("filename " + in_filename + " not exist ");
			logger.error("Exception message:" + ioe.getMessage());
		}
	}

	private void connect() {
		loadConnectionConf();
		String connectionUrl = connectionProperties.getProperty("url")
				+ connectionProperties.getProperty("host") + ":"
				+ connectionProperties.getProperty("port") + ":"
				+ connectionProperties.getProperty("sid");
		try {
			Class.forName(connectionProperties.getProperty("driver"));
			conn = DriverManager.getConnection(connectionUrl,
					connectionProperties.getProperty("username"),
					connectionProperties.getProperty("password"));
			logger.info("Connected to: " + connectionUrl);
		} catch (ClassNotFoundException ex) {
			logger.error("Driver not found");
			logger.error("Exception message:" + ex.getMessage());
		} catch (SQLException ex) {
			logger.error("Connection Failed");
			logger.error("Exception message:" + ex.getMessage());
			throw new NoDBConnectionException();
		}
	}

	private void writeConnectionPropertiesFile() {
		String folder = "C:/theyellowdaily/conf";
		new File(folder).mkdir();
		Properties dbProps = new Properties();
		String in_filename = "connection.properties";
		File f= new File(folder+"/"+in_filename);
		InputStream is = getClass().getResourceAsStream("/" + in_filename);
		try {
			dbProps.load(is);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		try {
			if(f.createNewFile()) {
				try {
					FileOutputStream fos = new FileOutputStream(f);
					dbProps.store(fos, "Connection Properties of The Yellow Daily");
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
}