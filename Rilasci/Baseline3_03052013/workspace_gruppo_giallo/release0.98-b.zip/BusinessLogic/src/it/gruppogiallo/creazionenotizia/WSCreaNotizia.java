package it.gruppogiallo.creazionenotizia;

import org.apache.log4j.Logger;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Notizia;
import it.gruppogiallo.security.Security;

public class WSCreaNotizia {

	private SuperDAO dao;
	private static final Logger logger = Logger.getLogger(WSCreaNotizia.class);

	public boolean creaNotizia(String loggedAccountUsername,
			String loggedAccountPassword, String titolo, String sottotitolo,
			String tipologiaNotizia, String testo) {
		logger.debug("WEBSERVICE: WSCreaNotizia - Service "
				+ " crea called in BL");
		boolean result = false;
		Security security = new Security();

		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "CreazioneNotizia")) {
			dao = new SuperDAO();
			Notizia notizia = new Notizia();
			notizia.setStato("S");
			notizia.setLockNotizia("N");
			notizia.setTesto(testo);
			notizia.setTitolo(titolo);
			notizia.setSottotitolo(sottotitolo);
			notizia.setTipologiaNotizia(tipologiaNotizia);
			notizia.setLunghezzaTesto(testo.length());
			System.out.println(notizia.toString());
			result = dao.createNotizia(notizia, loggedAccountUsername);
		}
		return result;
	}
}
