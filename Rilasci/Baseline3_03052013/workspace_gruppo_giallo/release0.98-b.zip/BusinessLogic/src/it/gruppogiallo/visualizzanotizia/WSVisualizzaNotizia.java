package it.gruppogiallo.visualizzanotizia;

import org.apache.log4j.Logger;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Notizia;
import it.gruppogiallo.security.Security;

public class WSVisualizzaNotizia {

	private SuperDAO dao;
	private static final Logger logger = Logger
			.getLogger(WSVisualizzaNotizia.class);

	public Notizia visualizzaNotizia(String loggedAccountUsername,
			String loggedAccountPassword, long id) {

		Notizia notizia = new Notizia();
		logger.debug("WEBSERVICE: WSVisualizzaNotizia - Service "
				+ " visualizzaNotizia called in BL");
		Security security = new Security();
		if (security.getPermission(loggedAccountUsername,
				loggedAccountPassword, "visualizzaNotizia")) {
			dao = new SuperDAO();
			notizia = dao.visualizzaNotizia(id);
		}
		return notizia;
	}
}
