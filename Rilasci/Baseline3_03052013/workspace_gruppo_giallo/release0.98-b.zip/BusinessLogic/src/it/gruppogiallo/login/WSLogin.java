package it.gruppogiallo.login;

import org.apache.log4j.Logger;

import it.gruppogiallo.dao.impl.SuperDAO;
import it.gruppogiallo.entity.Account;

public class WSLogin {

	private SuperDAO dao;
	private static final Logger logger = Logger.getLogger(WSLogin.class);

	public Account getLogin(String username, String password) {
		logger.debug("WEBSERVICE: WSLogin - Service "
				+ " getLogin called in BL");
		dao = new SuperDAO();
		return dao.getLogin(username, password);
	}
}
