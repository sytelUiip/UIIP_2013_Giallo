package it.gruppogiallo.bl.test;

import it.gruppogiallo.registranotizia.WSRegistraNotizia;

public class testRegistra {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		WSRegistraNotizia reg = new WSRegistraNotizia();
		boolean res = false;
		res = reg.registraNotizia("admin", "114cniiuinkmjk72aa1p5807u3", 7, "and", "co�in", "and", "and");
		System.out.println(res);

	}

}
